const fs = require('fs');

const filePath = './src/lib/mock-japanese-topology.ts';
let content = fs.readFileSync(filePath, 'utf8');

content = content.replace(/("layer": "ISL \(Inter-Satellite Link\)",)/g, '$1\n        "inventoryMappingAttributes": {\n            "linkType": "free-space-optics"\n        },');
content = content.replace(/("layer": "NTN-Backhaul",)/g, '$1\n        "inventoryMappingAttributes": {\n            "linkType": "free-space-optics"\n        },');

fs.writeFileSync(filePath, content, 'utf8');
console.log('Database mock updated successfully');
