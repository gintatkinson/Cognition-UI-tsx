const fs = require('fs');
const path = require('path');

const topoPath = path.join(__dirname, 'src', 'lib', 'mock-japanese-topology.ts');
let content = fs.readFileSync(topoPath, 'utf8');

// We have ground nodes and corresponding CU/TerraBeam nodes.
const groundNodes = [
    'node-TK1', 'node-TH_OTE', 'node-TY1', 'node-CC1', 
    'node-FUJI_SUMMIT', 'node-TYO2', 'node-M_CLS', 'node-OS1', 
    'node-OS3', 'node-DC12', 'node-EQ_OS1', 'node-KOZU', 
    'node-SP_OD', 'node-SD_CH', 'node-NG_SM', 'node-FK_TJ', 'node-OK_NH'
];

groundNodes.forEach(nodeUuid => {
    // 1. Extract the ietfGeoLocation block from the base node if it exists
    // It looks like:
    // "ietfGeoLocation": { ... },
    // We can use a regex to capture it. It ends when we see the next root key like "hardware": [ or "services": [
    // This is a bit tricky with regex. Let's do string indexOf parsing.

    let geoLocString = '';
    const nodeIndex = content.indexOf(`"uuid": "${nodeUuid}"`);
    if (nodeIndex !== -1) {
        const geoIndex = content.indexOf('"ietfGeoLocation": {', nodeIndex);
        const hardwareIndex = content.indexOf('"hardware": [', nodeIndex);
        if (geoIndex !== -1 && hardwareIndex !== -1 && geoIndex < hardwareIndex) {
            geoLocString = content.substring(geoIndex, hardwareIndex).trim();
            if (geoLocString.endsWith(',')) geoLocString = geoLocString.slice(0, -1);
        }
    }

    const cuUuid = 'CU-' + nodeUuid;
    const tbUuid = 'TerraBeam-' + nodeUuid;

    // For CU and TB nodes, inject bootDatetime inside clock block
    // "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
    const bootStr = `"bootDatetime": "2026-04-01T08:15:00.000Z", `;
    
    [cuUuid, tbUuid].forEach(targetUuid => {
        const targetIndex = content.indexOf(`"uuid": "${targetUuid}"`);
        if (targetIndex !== -1) {
            // Fix clock
            const clockIndex = content.indexOf('"clock": {', targetIndex);
            if (clockIndex !== -1) {
                const tzIndex = content.indexOf('"timezoneName":', clockIndex);
                if (tzIndex !== -1) {
                    // Make sure we haven't already added it
                    const clockBlock = content.substring(clockIndex, clockIndex + 150);
                    if (!clockBlock.includes('bootDatetime')) {
                        content = content.slice(0, tzIndex) + bootStr + content.slice(tzIndex);
                    }
                }
            }

            // Fix ietfGeoLocation
            if (geoLocString) {
                const hardwareIndexTarget = content.indexOf('"hardware": [', targetIndex);
                if (hardwareIndexTarget !== -1) {
                    // Make sure we haven't already added ietfGeoLocation
                    const nodeStr = content.substring(targetIndex, hardwareIndexTarget);
                    if (!nodeStr.includes('"ietfGeoLocation"')) {
                        content = content.slice(0, hardwareIndexTarget) + geoLocString + ',\n        ' + content.slice(hardwareIndexTarget);
                    }
                }
            }
        }
    });
});

fs.writeFileSync(topoPath, content, 'utf8');
console.log("Successfully fixed missing data for standalone nodes.");
