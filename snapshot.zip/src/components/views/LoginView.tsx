import React from 'react';
import { useAuth } from '../../lib/AuthContext';
import { Loader2 } from 'lucide-react';

export const LoginView: React.FC = () => {
  const { signInWithGoogle, loading, user } = useAuth();

  if (loading) {
    return (
      <div className="flex bg-background items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  // If already user but we somehow render Login
  if (user) {
    return null;
  }

  return (
    <div className="flex min-h-screen bg-background text-foreground items-center justify-center">
      <div className="max-w-md w-full px-6 py-12 flex flex-col items-center border border-border/50 rounded-xl bg-background/50">
        <div className="w-12 h-12 bg-emerald-500/10 rounded-full flex items-center justify-center mb-6">
          <div className="w-6 h-6 rounded-full bg-emerald-500" />
        </div>
        <h1 className="text-2xl font-bold font-sans tracking-tight mb-2">Sign in to Cognitive Controller</h1>
        <p className="text-muted-foreground text-sm mb-8 text-center max-w-sm">
          Authenticate with your Google account to access the control plane dashboard.
        </p>
        
        <button
          onClick={signInWithGoogle}
          className="w-full flex items-center justify-center gap-3 px-4 py-3 bg-white text-zinc-950 rounded-lg font-medium hover:bg-zinc-100 transition-colors"
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24">
            <path
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              fill="#4285F4"
            />
            <path
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              fill="#34A853"
            />
            <path
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              fill="#FBBC05"
            />
            <path
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              fill="#EA4335"
            />
            <path d="M1 1h22v22H1z" fill="none" />
          </svg>
          Continue with Google
        </button>
      </div>
    </div>
  );
};
