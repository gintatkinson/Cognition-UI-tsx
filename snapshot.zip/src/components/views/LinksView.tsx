
import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  MoreHorizontal, 
  Share2, 
  Maximize2, 
  Minimize2, 
  Network, 
  GripHorizontal 
} from 'lucide-react';
import { NetworkService } from '../../services/networkService';
import { cn } from '@/lib/utils';
import { TopologyGraph } from '../topology/TopologyGraph';

interface LinksViewProps {
  onNavigate: (id: string, type: 'device' | 'link' | 'service' | 'slice' | 'port' | 'hardware' | 'channel' | 'acl') => void;
  selectedTypes?: string[];
}

export function LinksView({ onNavigate, selectedTypes = ['L3_IP_MPLS', 'L2_ETHERNET', 'L0_OPTICAL'] }: LinksViewProps) {
  const [selectedLinkIds, setSelectedLinkIds] = useState<string[]>([]);
  const [highlightedLinkId, setHighlightedLinkId] = useState<string | null>(null);
  const [isGraphMaximized, setIsGraphMaximized] = useState(false);
  const [graphHeight, setGraphHeight] = useState(240);
  const [isResizing, setIsResizing] = useState(false);
  const [inspectHeight, setInspectHeight] = useState(180);
  const [isInspectResizing, setIsInspectResizing] = useState(false);

  const ietfTopology = NetworkService.getInstance().getTopology();

  // Helper mapping
  const layerMap: Record<string, string> = {
    'L3_IP_MPLS': 'L3 (IP/MPLS)',
    'L2_ETHERNET': 'L2 (Ethernet)',
    'L0_OPTICAL': 'L0 (Optical)'
  };

  const filteredLinks = useMemo(() => 
    ietfTopology.links.filter(link => {
      if (selectedTypes.length === 0) return true;
      const layerString = link.layer.toString();
      return selectedTypes.some(type => {
        const mapped = layerMap[type];
        return mapped ? layerString === mapped : layerString.includes(type);
      });
    }),
    [ietfTopology.links, selectedTypes]
  );

  // Highlight first link inside list initially
  useEffect(() => {
    if (filteredLinks.length > 0 && !highlightedLinkId) {
      setHighlightedLinkId(filteredLinks[0].uuid);
    }
  }, [filteredLinks, highlightedLinkId]);

  const highlightedLink = useMemo(() => 
    filteredLinks.find(l => l.uuid === highlightedLinkId),
    [filteredLinks, highlightedLinkId]
  );

  const graphLinks = useMemo(() => 
    ietfTopology.links.filter(l => selectedLinkIds.includes(l.uuid)),
    [selectedLinkIds, ietfTopology.links]
  );

  const graphDevices = useMemo(() => {
    const deviceIds = new Set<string>();
    graphLinks.forEach(l => {
      deviceIds.add(l.sourceNodeUuid);
      deviceIds.add(l.targetNodeUuid);
    });
    return ietfTopology.nodes.filter(d => deviceIds.has(d.uuid));
  }, [graphLinks, ietfTopology.nodes]);

  const toggleLinkSelection = (id: string) => {
    setSelectedLinkIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const toggleAllSelection = () => {
    if (selectedLinkIds.length === filteredLinks.length) {
      setSelectedLinkIds([]);
    } else {
      setSelectedLinkIds(filteredLinks.map(l => l.uuid));
    }
  };

  const startResizing = useCallback((e: React.MouseEvent) => {
    setIsResizing(true);
    e.preventDefault();
  }, []);

  const stopResizing = useCallback(() => {
    setIsResizing(false);
  }, []);

  const resize = useCallback((e: MouseEvent) => {
    if (isResizing) {
      setGraphHeight(prevHeight => {
        const newHeight = prevHeight + e.movementY;
        return Math.max(150, Math.min(800, newHeight));
      });
    }
  }, [isResizing]);

  useEffect(() => {
    if (isResizing) {
      window.addEventListener('mousemove', resize);
      window.addEventListener('mouseup', stopResizing);
    } else {
      window.removeEventListener('mousemove', resize);
      window.removeEventListener('mouseup', stopResizing);
    }
    return () => {
      window.removeEventListener('mousemove', resize);
      window.removeEventListener('mouseup', stopResizing);
    };
  }, [isResizing, resize, stopResizing]);

  const startInspectResizing = useCallback((e: React.MouseEvent) => {
    setIsInspectResizing(true);
    e.preventDefault();
  }, []);

  const stopInspectResizing = useCallback(() => {
    setIsInspectResizing(false);
  }, []);

  const resizeInspect = useCallback((e: MouseEvent) => {
    if (isInspectResizing) {
      setInspectHeight(prevHeight => {
        const newHeight = prevHeight - e.movementY;
        return Math.max(120, Math.min(500, newHeight));
      });
    }
  }, [isInspectResizing]);

  useEffect(() => {
    if (isInspectResizing) {
      window.addEventListener('mousemove', resizeInspect);
      window.addEventListener('mouseup', stopInspectResizing);
    } else {
      window.removeEventListener('mousemove', resizeInspect);
      window.removeEventListener('mouseup', stopInspectResizing);
    }
    return () => {
      window.removeEventListener('mousemove', resizeInspect);
      window.removeEventListener('mouseup', stopInspectResizing);
    };
  }, [isInspectResizing, resizeInspect, stopInspectResizing]);

  return (
    <div className="flex flex-col h-full gap-6">
      <div className="flex items-center justify-between shrink-0">
        <div>
          <h2 className="text-2xl font-bold text-foreground tracking-tight">IETF Network Links</h2>
          <p className="text-muted-foreground text-sm">Physical and logical connections (ietf-network-topology)</p>
        </div>
      </div>

      {/* Contextual Topology View */}
      <div 
        className={cn(
          "relative transition-[width,left,top,right,bottom] duration-500 ease-in-out group shrink-0",
          isGraphMaximized ? "fixed inset-8 z-50 bg-background" : "w-full"
        )}
        style={!isGraphMaximized ? { height: `${graphHeight}px` } : {}}
      >
        <div className="absolute top-4 left-4 z-10 flex items-center gap-2 bg-muted/80 backdrop-blur border border-border px-3 py-1.5 rounded-full">
          <Network className="w-3 h-3 text-blue-500" />
          <span className="text-[10px] font-mono font-bold text-foreground/80 uppercase tracking-widest">
            Link Topology ({selectedLinkIds.length} links)
          </span>
        </div>
        
        <Button 
          size="icon" 
          variant="secondary" 
          onClick={() => setIsGraphMaximized(!isGraphMaximized)}
          className="absolute top-4 right-4 z-10 bg-muted/80 border border-border text-muted-foreground hover:text-foreground/90"
        >
          {isGraphMaximized ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </Button>

        <div className="w-full h-full rounded-xl border border-border overflow-hidden bg-background/50">
          {selectedLinkIds.length > 0 ? (
            <TopologyGraph 
              devices={graphDevices.map(d => ({ id: d.uuid, name: d.name, type: d.layer, status: 'OPERATIONAL' as const, endpoints: d.ietfInterfaces?.map(i => i.name) || [], location: { latitude: d.ietfGeoLocation?.location?.ellipsoid?.latitude || 0, longitude: d.ietfGeoLocation?.location?.ellipsoid?.longitude || 0 }, component_count: d.hardware.length, drivers: [] }))} 
              links={graphLinks.map(l => ({ id: l.uuid, source: l.sourceNodeUuid, target: l.targetNodeUuid, capacity: l.capacity, type: 'OPTICAL' as const, latency: '1ms', source_endpoint: l.sourcePortUuid, target_endpoint: l.targetPortUuid }))} 
              onNavigate={onNavigate} 
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center text-muted-foreground/80 space-y-2">
              <Network className="w-8 h-8 opacity-20" />
              <p className="text-xs font-mono uppercase tracking-tighter">Select links below to build topology</p>
            </div>
          )}
        </div>

        {!isGraphMaximized && (
          <div 
            onMouseDown={startResizing}
            className={cn(
              "absolute -bottom-3 left-1/2 -translate-x-1/2 w-12 h-6 flex items-center justify-center cursor-ns-resize z-20 transition-opacity",
              isResizing ? "opacity-100" : "opacity-0 group-hover:opacity-100"
            )}
          >
            <div className="bg-muted border border-zinc-700 rounded-full px-2 py-0.5 shadow-xl hover:bg-zinc-700 transition-colors">
              <GripHorizontal className="w-4 h-4 text-muted-foreground" />
            </div>
          </div>
        )}
      </div>

      <div className="bg-background border border-border rounded-lg flex-1 min-h-[120px] overflow-auto">
        <Table>
          <TableHeader className="bg-muted/50 sticky top-0 z-10 border-b border-border">
            <TableRow className="border-border hover:bg-transparent">
              <TableHead className="w-12">
                <Checkbox 
                  checked={selectedLinkIds.length === filteredLinks.length && filteredLinks.length > 0}
                  onCheckedChange={toggleAllSelection}
                  className="border-zinc-700 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600 h-3.5 w-3.5"
                />
              </TableHead>
              <TableHead className="text-muted-foreground font-mono text-[10px] uppercase tracking-wider">Link UUID</TableHead>
              <TableHead className="text-muted-foreground font-mono text-[10px] uppercase tracking-wider">Layer Type</TableHead>
              <TableHead className="text-muted-foreground font-mono text-[10px] uppercase tracking-wider">Source Node/Port</TableHead>
              <TableHead className="text-muted-foreground font-mono text-[10px] uppercase tracking-wider">Target Node/Port</TableHead>
              <TableHead className="text-muted-foreground font-mono text-[10px] uppercase tracking-wider">Capacity</TableHead>
              <TableHead className="text-right text-muted-foreground font-mono text-[10px] uppercase tracking-wider">Drill-down</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredLinks.map((link) => {
              const isHighlighted = highlightedLinkId === link.uuid;
              return (
                <TableRow 
                  key={link.uuid} 
                  className={cn(
                    "border-border hover:bg-muted/20 transition-colors group cursor-pointer",
                    isHighlighted && "bg-blue-950/20 shadow-inner border-l-2 border-l-blue-500/80"
                  )}
                  onClick={() => setHighlightedLinkId(link.uuid)}
                  onDoubleClick={() => onNavigate(link.uuid, 'link')}
                  data-nav-id={link.uuid}
                  data-nav-type="link"
                  title="Single-click to select attributes | Double-click to inspect detailed model"
                >
                  <TableCell onClick={(e) => { e.stopPropagation(); toggleLinkSelection(link.uuid); }}>
                    <Checkbox 
                      checked={selectedLinkIds.includes(link.uuid)}
                      onCheckedChange={() => toggleLinkSelection(link.uuid)}
                      className="border-zinc-700 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600 h-3.5 w-3.5"
                    />
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    <span 
                      className="hover:underline hover:text-blue-400 cursor-pointer" 
                      onClick={(e) => { e.stopPropagation(); onNavigate(link.uuid, 'link'); }}
                    >
                      {link.uuid}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="outline" 
                      className="text-[9px] px-1.5 py-0 border-blue-500/20 text-blue-500 bg-blue-500/10 font-mono"
                    >
                      {link.layer}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-foreground/90">
                    <div className="flex flex-col">
                      <span 
                        className="font-medium text-xs font-mono hover:underline hover:text-blue-400 cursor-pointer" 
                        onClick={(e) => { e.stopPropagation(); onNavigate(link.sourceNodeUuid, 'device'); }}
                        data-nav-id={link.sourceNodeUuid}
                        data-nav-type="device"
                      >
                        {ietfTopology.nodes.find(n => n.uuid === link.sourceNodeUuid)?.name || link.sourceNodeUuid}
                      </span>
                      <span 
                        className="text-[9.5px] text-muted-foreground font-mono hover:underline hover:text-blue-400 cursor-pointer"
                        onClick={(e) => { e.stopPropagation(); onNavigate(`${link.sourceNodeUuid}/${link.sourcePortUuid}`, 'port'); }}
                        data-nav-id={`${link.sourceNodeUuid}/${link.sourcePortUuid}`}
                        data-nav-type="port"
                      >
                        {link.sourcePortUuid}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-foreground/90">
                    <div className="flex flex-col">
                      <span 
                        className="font-medium text-xs font-mono hover:underline hover:text-blue-400 cursor-pointer" 
                        onClick={(e) => { e.stopPropagation(); onNavigate(link.targetNodeUuid, 'device'); }}
                        data-nav-id={link.targetNodeUuid}
                        data-nav-type="device"
                      >
                        {ietfTopology.nodes.find(n => n.uuid === link.targetNodeUuid)?.name || link.targetNodeUuid}
                      </span>
                      <span 
                        className="text-[9.5px] text-muted-foreground font-mono hover:underline hover:text-blue-400 cursor-pointer"
                        onClick={(e) => { e.stopPropagation(); onNavigate(`${link.targetNodeUuid}/${link.targetPortUuid}`, 'port'); }}
                        data-nav-id={`${link.targetNodeUuid}/${link.targetPortUuid}`}
                        data-nav-type="port"
                      >
                        {link.targetPortUuid}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="bg-muted text-muted-foreground border-border text-[9.5px] font-mono">
                      {link.capacity}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button 
                      variant="secondary" 
                      size="sm" 
                      className="h-6 text-[10px] py-0 px-2 font-mono bg-zinc-900 border border-border text-zinc-300 hover:text-white"
                      onClick={(e) => { e.stopPropagation(); onNavigate(link.uuid, 'link'); }}
                    >
                      Details
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      {/* Split Attribute Inspect Panel */}
      <div 
        style={{ height: `${inspectHeight}px` }}
        className="relative border border-border rounded-lg bg-zinc-950/40 shrink-0 overflow-y-auto group/inspect flex flex-col font-sans"
      >
        {/* Resize Handle */}
        <div 
          onMouseDown={startInspectResizing}
          className={cn(
            "absolute top-0.5 left-1/2 -translate-x-1/2 w-12 h-3 flex items-center justify-center cursor-ns-resize z-20 transition-opacity",
            isInspectResizing ? "opacity-100" : "opacity-0 group-hover/inspect:opacity-100"
          )}
        >
          <div className="bg-muted border border-zinc-700 rounded-full px-1.5 py-0.5 shadow-md hover:bg-zinc-700 transition-colors">
            <GripHorizontal className="w-3.5 h-3.5 text-muted-foreground/80" />
          </div>
        </div>

        {highlightedLink ? (
          <div className="p-4 space-y-3 flex-1 overflow-y-auto min-h-0">
            <div className="flex items-center justify-between border-b border-border/50 pb-2">
              <div className="flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                </span>
                <h4 className="text-xs font-bold font-mono text-zinc-200">
                  Quick-Inspect Panel: Link {highlightedLink.uuid}
                </h4>
              </div>
              <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest">
                Double-click row to view full telemetry
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-normal text-muted-foreground/90 font-mono">
              {/* Column 1: Capacity */}
              <div className="space-y-1.5 p-2 bg-zinc-900/30 rounded border border-border/40 font-mono text-xs">
                <div className="flex items-center gap-1 text-[10px] font-bold text-zinc-400 uppercase tracking-wider font-sans">
                  <Network className="w-3.5 h-3.5 text-blue-500" />
                  <span>Topology Information</span>
                </div>
                <div className="space-y-1">
                  <p><strong className="text-zinc-400">Layer Range:</strong> {highlightedLink.layer}</p>
                  <p><strong className="text-zinc-400">Max Capacity:</strong> {highlightedLink.capacity}</p>
                  <p><strong className="text-zinc-400">Compliance:</strong> IETF RFC 8345</p>
                </div>
              </div>

              {/* Column 2: Source Node */}
              <div className="space-y-1.5 p-2 bg-zinc-900/30 rounded border border-border/40 font-mono text-xs">
                <div className="flex items-center gap-1 text-[10px] font-bold text-zinc-400 uppercase tracking-wider font-sans">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
                  <span>Source Adjacency</span>
                </div>
                <div className="space-y-1">
                  <p>
                    <strong className="text-zinc-400">Node:</strong>{' '}
                    <span 
                      className="cursor-pointer hover:underline text-indigo-400 font-bold"
                      onClick={() => onNavigate(highlightedLink.sourceNodeUuid, 'device')}
                      data-nav-id={highlightedLink.sourceNodeUuid}
                      data-nav-type="device"
                    >
                      {ietfTopology.nodes.find(n => n.uuid === highlightedLink.sourceNodeUuid)?.name || highlightedLink.sourceNodeUuid}
                    </span>
                  </p>
                  <p>
                    <strong className="text-zinc-400">TP Port:</strong>{' '}
                    <span 
                      className="cursor-pointer hover:underline text-blue-400 font-semibold"
                      onClick={() => onNavigate(`${highlightedLink.sourceNodeUuid}/${highlightedLink.sourcePortUuid}`, 'port')}
                      data-nav-id={`${highlightedLink.sourceNodeUuid}/${highlightedLink.sourcePortUuid}`}
                      data-nav-type="port"
                    >
                      {highlightedLink.sourcePortUuid}
                    </span>
                  </p>
                </div>
              </div>

              {/* Column 3: Target Node */}
              <div className="space-y-1.5 p-2 bg-zinc-900/30 rounded border border-border/40 font-mono text-xs">
                <div className="flex items-center gap-1 text-[10px] font-bold text-zinc-400 uppercase tracking-wider font-sans">
                  <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full" />
                  <span>Target Adjacency</span>
                </div>
                <div className="space-y-1">
                  <p>
                    <strong className="text-zinc-400">Node:</strong>{' '}
                    <span 
                      className="cursor-pointer hover:underline text-indigo-400 font-bold"
                      onClick={() => onNavigate(highlightedLink.targetNodeUuid, 'device')}
                      data-nav-id={highlightedLink.targetNodeUuid}
                      data-nav-type="device"
                    >
                      {ietfTopology.nodes.find(n => n.uuid === highlightedLink.targetNodeUuid)?.name || highlightedLink.targetNodeUuid}
                    </span>
                  </p>
                  <p>
                    <strong className="text-zinc-400">TP Port:</strong>{' '}
                    <span 
                      className="cursor-pointer hover:underline text-blue-400 font-semibold"
                      onClick={() => onNavigate(`${highlightedLink.targetNodeUuid}/${highlightedLink.targetPortUuid}`, 'port')}
                      data-nav-id={`${highlightedLink.targetNodeUuid}/${highlightedLink.targetPortUuid}`}
                      data-nav-type="port"
                    >
                      {highlightedLink.targetPortUuid}
                    </span>
                  </p>
                </div>
              </div>

              {/* Column 4: SLA */}
              <div className="space-y-1.5 p-2 bg-zinc-900/30 rounded border border-border/40 font-mono text-xs">
                <div className="flex items-center gap-1 text-[10px] font-bold text-zinc-400 uppercase tracking-wider font-sans">
                  <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse" />
                  <span>Operational State</span>
                </div>
                <div className="space-y-1">
                  <p><strong className="text-zinc-400">SLA Latency:</strong> 0.24 ms</p>
                  <p><strong className="text-zinc-400">Admin Status:</strong> <span className="text-emerald-400">UP</span></p>
                  <p><strong className="text-zinc-400">Oper Status:</strong> <span className="text-emerald-400">UP</span></p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center p-8 text-center text-muted-foreground/70 text-xs text-mono bg-zinc-950/20">
            Click a link row above to dynamically load object attributes
          </div>
        )}
      </div>
    </div>
  );
}
