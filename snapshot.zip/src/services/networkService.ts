
import { 
  NetworkTopology, 
  NetworkElement, 
  NetworkLayer, 
  HardwareComponent, 
  ServiceInstance, 
  NetworkLink, 
  IETFGeoLocation,
  PassiveDevice,
  PassiveCable,
  PassivePort,
  ChildCable,
  RFC8345Network,
  RFC8345Node,
  SupportingNetwork,
  SupportingNode,
  SupportingLink,
  RFC8345Link,
  RFC8345TerminationPoint,
  SupportingTerminationPoint
} from '../types';
import { getJapaneseOpticalTopology } from '../lib/mock-japanese-topology';

export class NetworkService {
  private static instance: NetworkService;
  private topology: NetworkTopology;
  private hasInventoryTopology: boolean = true; // Enabled by default
  private passiveDevices: PassiveDevice[] = [];
  private passiveCables: PassiveCable[] = [];
  private rfc8345Networks: RFC8345Network[] = [];

  private constructor() {
    this.topology = getJapaneseOpticalTopology();
    this.initializeDefaultInventoryMappings();
    this.initializeDefaultPassiveInventory();
    this.initializeDefaultBaseNetworks();
  }

  public static getInstance(): NetworkService {
    if (!NetworkService.instance) {
      NetworkService.instance = new NetworkService();
    }
    return NetworkService.instance;
  }

  public getTopology(): NetworkTopology {
    return this.topology;
  }

  public isInventoryTopologyActive(): boolean {
    return this.hasInventoryTopology;
  }

  public setInventoryTopologyActive(active: boolean) {
    this.hasInventoryTopology = active;
  }

  public updateNodeNeRef(nodeUuid: string, neRef: string | undefined) {
    const node = this.topology.nodes.find(n => n.uuid === nodeUuid);
    if (node) {
      node.inventoryMappingAttributes = {
        neRef: neRef
      };
    }
  }

  public updateLinkType(linkUuid: string, linkType: 'copper' | 'fiber' | 'coax' | 'microwave' | 'wlan' | 'unknown' | 'leased-fiber' | 'free-space-optics' | undefined) {
    const link = this.topology.links.find(l => l.uuid === linkUuid);
    if (link) {
      link.inventoryMappingAttributes = {
        linkType: linkType
      };
    }
  }

  public updateInterfaceBreakout(nodeUuid: string, interfaceName: string, enabled: boolean, channels: { channelId: number; speed?: number; status?: 'up' | 'down' }[]) {
    const node = this.topology.nodes.find(n => n.uuid === nodeUuid);
    if (node && node.ietfInterfaces) {
      const iface = node.ietfInterfaces.find(i => i.name === interfaceName);
      if (iface) {
        iface.portBreakout = {
          enabled: enabled,
          breakoutChannels: channels
        };
      }
    }
  }

  private initializeDefaultInventoryMappings() {
    this.topology.nodes.forEach((node, idx) => {
      node.inventoryMappingAttributes = {
        neRef: node.uuid // Default 1:1 logical node to physical element correlation
      };

      if (node.ietfInterfaces && node.ietfInterfaces.length > 0) {
        // Set up support interface as a sample of channel breakout
        node.ietfInterfaces[0].portBreakout = {
          enabled: idx % 2 === 0, // Enabled on 50% of elements by default
          breakoutChannels: [
            { channelId: 1, speed: 100000000000, status: 'up' },
            { channelId: 2, speed: 100000000000, status: 'up' },
            { channelId: 3, speed: 100000000000, status: 'down' },
            { channelId: 4, speed: 100000000000, status: 'up' }
          ]
        };
      }
    });

    const mediaTypes: ('copper' | 'fiber' | 'coax' | 'microwave' | 'wlan' | 'leased-fiber')[] = [
      'fiber', 'leased-fiber', 'microwave', 'copper', 'wlan'
    ];
    this.topology.links.forEach((link, idx) => {
      let linkType: 'copper' | 'fiber' | 'coax' | 'microwave' | 'wlan' | 'leased-fiber' | 'unknown' | 'free-space-optics' = mediaTypes[idx % mediaTypes.length];
      
      const isSatelliteRelated = 
        link.sourceNodeUuid.includes('SAT') || 
        link.targetNodeUuid.includes('SAT') || 
        (link.layer && (link.layer.toString().includes('Satellite') || link.layer.toString().includes('ISL') || link.layer.toString().includes('NTN')));

      if (isSatelliteRelated) {
        const isISL = 
          (link.sourceNodeUuid.includes('SAT') && link.targetNodeUuid.includes('SAT')) ||
          (link.layer && link.layer.toString().includes('ISL'));

        if (isISL) {
          // All Inter-Satellite Links (ISL) are free space optical/laser links
          linkType = 'free-space-optics';
        } else {
          // Satellite-to-ground backhaul downlinks are a mix of microwave and FSO (laser) links, never physical fiber!
          linkType = idx % 2 === 0 ? 'microwave' : 'free-space-optics';
        }
      }

      link.inventoryMappingAttributes = {
        linkType
      };
    });
  }

  private generateRandomStatistics() {
    const baseOctets = Math.floor(Math.random() * 1000000000);
    const basePkts = Math.floor(baseOctets / 1500);
    return {
      inOctets: baseOctets + Math.floor(Math.random() * 500000),
      inUnicastPkts: basePkts + Math.floor(Math.random() * 1000),
      inErrors: Math.floor(Math.random() * 10),
      inDiscards: Math.floor(Math.random() * 5),
      outOctets: baseOctets + Math.floor(Math.random() * 500000),
      outUnicastPkts: basePkts + Math.floor(Math.random() * 1000),
      outErrors: Math.floor(Math.random() * 10),
      outDiscards: Math.floor(Math.random() * 5)
    };
  }

  private generateMockTopology(): NetworkTopology {
    const nodes: NetworkElement[] = [
      {
        uuid: 'd1',
        name: 'R1-Core',
        type: 'ROUTER',
        layer: NetworkLayer.L3_IP_MPLS,
        location: 'Frankfurt-DC-Core',
        ietfSystem: {
          hostname: 'fra-r1-core',
          contact: 'noc@telecom.de',
          location: 'Frankfurt, Rack A1',
          platform: { osName: 'IPOS', osRelease: '18.1.1', osVersion: '18.1', machine: 'x86_64' },
          clock: { timezoneName: 'Europe/Berlin', bootDatetime: '2025-10-15T08:30:00Z', currentDatetime: new Date().toISOString() }
        },
        ietfGeoLocation: {
          referenceFrame: { astronomicalBody: 'earth', geodeticSystem: { geodeticDatum: 'wgs-84', coordAccuracy: 1.5 } },
          location: { ellipsoid: { latitude: 50.1109, longitude: 8.6821, height: 112 } }
        },
        ietfInterfaces: [
          { name: 'eth0', type: 'iana-if-type:ethernetCsmacd', enabled: true, adminStatus: 'up', operStatus: 'up', speed: 100000000000, physAddress: '00:1B:21:A4:D3:01', statistics: this.generateRandomStatistics() },
          { name: 'eth1', type: 'iana-if-type:ethernetCsmacd', enabled: true, adminStatus: 'up', operStatus: 'up', speed: 100000000000, physAddress: '00:1B:21:A4:D3:02', statistics: this.generateRandomStatistics() }
        ],
        ietfAccessControlList: [
          { name: 'BOGON-FILTER-IN', matches: 'ipv4-source-prefix 10.0.0.0/8', actions: { forwarding: 'drop', logging: 'log-syslog' } },
          { name: 'BGP-PEER-ACCEPT', matches: 'tcp-destination-port 179', actions: { forwarding: 'accept', logging: 'none' } }
        ],
        hardware: [
          { uuid: 'h1_d1', name: 'PTX10008-Chassis', class: 'chassis', manufacturer: 'Juniper Networks', partNumber: 'JNP10008-CHAS', serialNumber: 'JN-PTX-112233', status: 'active' },
          { uuid: 'h2_d1', name: 'Routing-Engine', class: 'module', parentUuid: 'h1_d1', manufacturer: 'Juniper Networks', partNumber: 'JNP10008-RE0', serialNumber: 'JN-RE-445566', status: 'active' },
          { uuid: 'h3_d1', name: 'Line-Card-36x100G', class: 'module', parentUuid: 'h1_d1', manufacturer: 'Juniper Networks', partNumber: 'PTX10K-LC1201-36CD', serialNumber: 'JN-LC-778899', status: 'active' },
          { uuid: 'p1_d1', name: 'eth0-Optic', class: 'port', parentUuid: 'h3_d1', manufacturer: 'Juniper Networks', partNumber: 'JNP-QSFP-100G-LR4', serialNumber: 'JN-OP-100-3331', status: 'active' },
          { uuid: 'p2_d1', name: 'eth1-Optic', class: 'port', parentUuid: 'h3_d1', manufacturer: 'Juniper Networks', partNumber: 'JNP-QSFP-100G-LR4', serialNumber: 'JN-OP-100-3332', status: 'active' }
        ],
        services: [{ uuid: 's1', name: 'L3VPN-Enterprise', type: 'L3VPN', layer: NetworkLayer.L3_IP_MPLS, endpoints: ['eth0'], bandwidthValue: 10, bandwidthUnits: 'Gbps', status: 'up' }]
      },
      {
        uuid: 'd2',
        name: 'R2-Core',
        type: 'ROUTER',
        layer: NetworkLayer.L3_IP_MPLS,
        location: 'Munich-DC-Core',
        ietfSystem: {
          hostname: 'mun-r2-core',
          contact: 'noc@telecom.de',
          platform: { osName: 'IPOS', osRelease: '18.1.1', osVersion: '18.1', machine: 'x86_64' },
          clock: { timezoneName: 'Europe/Berlin', bootDatetime: '2026-01-10T12:00:00Z', currentDatetime: new Date().toISOString() }
        },
        ietfGeoLocation: {
          referenceFrame: { astronomicalBody: 'earth', geodeticSystem: { geodeticDatum: 'wgs-84', coordAccuracy: 2.0 } },
          location: { ellipsoid: { latitude: 48.1351, longitude: 11.5820, height: 520 } }
        },
        ietfInterfaces: [
          { name: 'eth0', type: 'iana-if-type:ethernetCsmacd', enabled: true, adminStatus: 'up', operStatus: 'up', speed: 100000000000, physAddress: '00:1B:21:B5:E4:01', statistics: this.generateRandomStatistics() },
          { name: 'eth1', type: 'iana-if-type:ethernetCsmacd', enabled: true, adminStatus: 'up', operStatus: 'up', speed: 100000000000, physAddress: '00:1B:21:B5:E4:02', statistics: this.generateRandomStatistics() },
          { name: 'eth2', type: 'iana-if-type:ethernetCsmacd', enabled: true, adminStatus: 'up', operStatus: 'up', speed: 40000000000, physAddress: '00:1B:21:B5:E4:03', statistics: this.generateRandomStatistics() }
        ],
        hardware: [
          { uuid: 'h1_d2', name: 'ASR-9922-Chassis', class: 'chassis', manufacturer: 'Cisco Systems', partNumber: 'ASR-9922', serialNumber: 'FOC2345ABCD', status: 'active' },
          { uuid: 'h2_d2', name: 'Route-Switch-Processor', class: 'module', parentUuid: 'h1_d2', manufacturer: 'Cisco Systems', partNumber: 'A9K-RSP5-SE', serialNumber: 'FOC2346XYZA', status: 'active' },
          { uuid: 'p1_d2', name: 'eth0-Optic', class: 'port', parentUuid: 'h2_d2', manufacturer: 'Cisco Systems', partNumber: 'QSFP-100G-LR4-S', serialNumber: 'FOC-OP-100-3333', status: 'active' },
          { uuid: 'p2_d2', name: 'eth1-Optic', class: 'port', parentUuid: 'h2_d2', manufacturer: 'Cisco Systems', partNumber: 'QSFP-100G-LR4-S', serialNumber: 'FOC-OP-100-3334', status: 'active' },
          { uuid: 'p3_d2', name: 'eth2-Optic', class: 'port', parentUuid: 'h2_d2', manufacturer: 'Cisco Systems', partNumber: 'QSFP-40G-SR4', serialNumber: 'FOC-OP-040-3335', status: 'active' }
        ],
        services: [{ uuid: 's2', name: 'L2VPN-Backup', type: 'E-Line', layer: NetworkLayer.L2_ETHERNET, endpoints: ['eth2'], bandwidthValue: 5, bandwidthUnits: 'Gbps', status: 'down' }]
      },
      {
        uuid: 'd3',
        name: 'SW1-Edge',
        type: 'SWITCH',
        layer: NetworkLayer.L2_ETHERNET,
        location: 'Berlin-Metro-1',
        ietfSystem: {
          hostname: 'ber-sw1-edge',
          contact: 'metro-ops@telecom.de',
          platform: { osName: 'EthOS', osRelease: '5.20.0', osVersion: '5.2', machine: 'arm64' },
          clock: { timezoneName: 'Europe/Berlin', bootDatetime: '2026-03-20T12:00:00Z', currentDatetime: new Date().toISOString() }
        },
        ietfGeoLocation: {
          referenceFrame: { astronomicalBody: 'earth', geodeticSystem: { geodeticDatum: 'wgs-84', coordAccuracy: 1.0 } },
          location: { ellipsoid: { latitude: 52.5200, longitude: 13.4050, height: 34 } }
        },
        ietfInterfaces: [
          { name: 'p1', type: 'iana-if-type:ethernetCsmacd', enabled: true, adminStatus: 'up', operStatus: 'up', speed: 40000000000, physAddress: 'AA:BB:CC:DD:EE:11', statistics: this.generateRandomStatistics() },
          { name: 'p2', type: 'iana-if-type:ethernetCsmacd', enabled: true, adminStatus: 'up', operStatus: 'up', speed: 40000000000, physAddress: 'AA:BB:CC:DD:EE:12', statistics: this.generateRandomStatistics() },
          { name: 'p3', type: 'iana-if-type:ethernetCsmacd', enabled: true, adminStatus: 'up', operStatus: 'up', speed: 10000000000, physAddress: 'AA:BB:CC:DD:EE:13', statistics: this.generateRandomStatistics() }
        ],
        hardware: [
          { uuid: 'h1_d3', name: 'QFX5120-Switch', class: 'chassis', manufacturer: 'Juniper Networks', partNumber: 'QFX5120-48Y', serialNumber: 'JN-QFX-998877', status: 'active' }
        ],
        services: [
          { uuid: 's1_d3', name: 'L3VPN-Enterprise', type: 'L3VPN', layer: NetworkLayer.L3_IP_MPLS, endpoints: ['p3'], bandwidthValue: 1, bandwidthUnits: 'Gbps', status: 'up' },
          { uuid: 's2_d3', name: 'L2VPN-Backup', type: 'E-Line', layer: NetworkLayer.L2_ETHERNET, endpoints: ['p1'], bandwidthValue: 1, bandwidthUnits: 'Gbps', status: 'down' }
        ]
      },
      {
        uuid: 'd4',
        name: 'SW2-Edge',
        type: 'SWITCH',
        layer: NetworkLayer.L2_ETHERNET,
        location: 'Hamburg-Metro-1',
        ietfSystem: {
          hostname: 'ham-sw2-edge',
          contact: 'metro-ops@telecom.de',
          platform: { osName: 'EthOS', osRelease: '5.20.0', osVersion: '5.2', machine: 'arm64' },
          clock: { timezoneName: 'Europe/Berlin', currentDatetime: new Date().toISOString() }
        },
        ietfGeoLocation: {
          referenceFrame: { astronomicalBody: 'earth', geodeticSystem: { geodeticDatum: 'wgs-84', coordAccuracy: 2.0 } },
          location: { ellipsoid: { latitude: 53.5511, longitude: 9.9937, height: 12 } }
        },
        ietfInterfaces: [
          { name: 'p1', type: 'iana-if-type:ethernetCsmacd', enabled: false, adminStatus: 'down', operStatus: 'down', speed: 40000000000, statistics: this.generateRandomStatistics() },
          { name: 'p2', type: 'iana-if-type:ethernetCsmacd', enabled: false, adminStatus: 'down', operStatus: 'down', speed: 40000000000, statistics: this.generateRandomStatistics() }
        ],
        hardware: [
          { uuid: 'h1_d4', name: 'Catalyst-9500', class: 'chassis', manufacturer: 'Cisco Systems', partNumber: 'C9500-48Y4C', serialNumber: 'FOC-C95-4444', status: 'faulty' }
        ],
        services: []
      },
      {
        uuid: 'q1',
        name: 'QKD-Node-Alpha',
        type: 'QKD_NODE',
        layer: NetworkLayer.L0_OPTICAL,
        location: 'Frankfurt-Crypto-Vault',
        ietfSystem: {
          hostname: 'fra-qkd-alpha',
          contact: 'sec-ops@telecom.de',
          platform: { osName: 'Q-Kernel', osRelease: '3.1.4', osVersion: '3.1', machine: 'custom-asic' },
          clock: { timezoneName: 'UTC', bootDatetime: '2026-04-01T00:00:00Z', currentDatetime: new Date().toISOString() }
        },
        ietfGeoLocation: {
          referenceFrame: { astronomicalBody: 'earth', geodeticSystem: { geodeticDatum: 'wgs-84', coordAccuracy: 0.1 } },
          location: { ellipsoid: { latitude: 50.1109, longitude: 8.6821, height: 110 } }
        },
        ietfInterfaces: [
          { name: 'q0', type: 'iana-if-type:opticalChannel', enabled: true, adminStatus: 'up', operStatus: 'up', description: 'Quantum Key Channel', statistics: this.generateRandomStatistics() },
          { name: 'q1', type: 'iana-if-type:opticalChannel', enabled: true, adminStatus: 'up', operStatus: 'up', description: 'Quantum Key Channel', statistics: this.generateRandomStatistics() }
        ],
        hardware: [
          { uuid: 'h1_q1', name: 'Cerberis-XG-Chassis', class: 'chassis', manufacturer: 'ID Quantique', partNumber: 'IDQ-CXG', serialNumber: 'IDQ-CXG-100', status: 'active' },
          { uuid: 'h2_q1', name: 'Clavis3-Module', class: 'module', parentUuid: 'h1_q1', manufacturer: 'ID Quantique', partNumber: 'IDQ-C3', serialNumber: 'IDQ-C3-001', status: 'active' },
          { uuid: 'p1_q1', name: 'q0-transceiver', class: 'transceiver', parentUuid: 'h2_q1', manufacturer: 'ID Quantique', partNumber: 'IDQ-SFP-1G-BIDI', serialNumber: 'IDQ-OP-3331', status: 'active' },
          { uuid: 'p2_q1', name: 'q1-transceiver', class: 'transceiver', parentUuid: 'h2_q1', manufacturer: 'ID Quantique', partNumber: 'IDQ-SFP-1G-BIDI', serialNumber: 'IDQ-OP-3332', status: 'active' }
        ],
        services: []
      },
      {
        uuid: 'q2',
        name: 'QKD-Node-Beta',
        type: 'QKD_NODE',
        layer: NetworkLayer.L0_OPTICAL,
        location: 'Munich-Crypto-Vault',
        ietfSystem: {
          hostname: 'mun-qkd-beta',
          contact: 'sec-ops@telecom.de',
          platform: { osName: 'Q-Kernel', osRelease: '3.1.4', osVersion: '3.1', machine: 'custom-asic' },
          clock: { timezoneName: 'UTC', bootDatetime: '2026-04-02T00:00:00Z', currentDatetime: new Date().toISOString() }
        },
        ietfGeoLocation: {
          referenceFrame: { astronomicalBody: 'earth', geodeticSystem: { geodeticDatum: 'wgs-84', coordAccuracy: 0.1 } },
          location: { ellipsoid: { latitude: 48.1351, longitude: 11.5820, height: 518 } }
        },
        ietfInterfaces: [
          { name: 'q0', type: 'iana-if-type:opticalChannel', enabled: true, adminStatus: 'up', operStatus: 'up', description: 'Quantum Key Channel', statistics: this.generateRandomStatistics() },
          { name: 'q1', type: 'iana-if-type:opticalChannel', enabled: true, adminStatus: 'up', operStatus: 'up', description: 'Quantum Key Channel', statistics: this.generateRandomStatistics() }
        ],
        hardware: [
          { uuid: 'h1_q2', name: 'Cerberis-XG-Chassis', class: 'chassis', manufacturer: 'ID Quantique', partNumber: 'IDQ-CXG', serialNumber: 'IDQ-CXG-101', status: 'active' },
          { uuid: 'h2_q2', name: 'Clavis3-Module', class: 'module', parentUuid: 'h1_q2', manufacturer: 'ID Quantique', partNumber: 'IDQ-C3', serialNumber: 'IDQ-C3-002', status: 'active' },
          { uuid: 'p1_q2', name: 'q0-transceiver', class: 'transceiver', parentUuid: 'h2_q2', manufacturer: 'ID Quantique', partNumber: 'IDQ-SFP-1G-BIDI', serialNumber: 'IDQ-OP-3333', status: 'active' },
          { uuid: 'p2_q2', name: 'q1-transceiver', class: 'transceiver', parentUuid: 'h2_q2', manufacturer: 'ID Quantique', partNumber: 'IDQ-SFP-1G-BIDI', serialNumber: 'IDQ-OP-3334', status: 'active' }
        ],
        services: []
      },
      {
        uuid: 'q3',
        name: 'QKD-Node-Gamma',
        type: 'QKD_NODE',
        layer: NetworkLayer.L0_OPTICAL,
        location: 'Berlin-Crypto-Vault',
        ietfSystem: {
          hostname: 'ber-qkd-gamma',
          contact: 'sec-ops@telecom.de',
          platform: { osName: 'Q-Kernel', osRelease: '3.1.4', osVersion: '3.1', machine: 'custom-asic' },
          clock: { timezoneName: 'UTC', bootDatetime: '2026-04-03T00:00:00Z', currentDatetime: new Date().toISOString() }
        },
        ietfGeoLocation: {
          referenceFrame: { astronomicalBody: 'earth', geodeticSystem: { geodeticDatum: 'wgs-84', coordAccuracy: 0.1 } },
          location: { ellipsoid: { latitude: 52.5200, longitude: 13.4050, height: 32 } }
        },
        ietfInterfaces: [
          { name: 'q0', type: 'iana-if-type:opticalChannel', enabled: true, adminStatus: 'up', operStatus: 'lower-layer-down', description: 'Quantum Key Channel - Fault', statistics: this.generateRandomStatistics() }
        ],
        hardware: [
          { uuid: 'h1_q3', name: 'Cerberis-XG-Chassis', class: 'chassis', manufacturer: 'ID Quantique', partNumber: 'IDQ-CXG', serialNumber: 'IDQ-CXG-102', status: 'faulty' },
          { uuid: 'h2_q3', name: 'Clavis3-Module', class: 'module', parentUuid: 'h1_q3', manufacturer: 'ID Quantique', partNumber: 'IDQ-C3', serialNumber: 'IDQ-C3-003', status: 'faulty' },
          { uuid: 'p1_q3', name: 'q0-transceiver', class: 'transceiver', parentUuid: 'h2_q3', manufacturer: 'ID Quantique', partNumber: 'IDQ-SFP-1G-BIDI', serialNumber: 'IDQ-OP-3335', status: 'faulty' }
        ],
        services: []
      }
    ];

    const links: NetworkLink[] = [
      { uuid: 'l1', sourceNodeUuid: 'd1', targetNodeUuid: 'd2', sourcePortUuid: 'eth0', targetPortUuid: 'eth0', layer: NetworkLayer.L3_IP_MPLS, capacity: '100 Gbps', usage: 45 },
      { uuid: 'l2', sourceNodeUuid: 'd2', targetNodeUuid: 'd3', sourcePortUuid: 'eth1', targetPortUuid: 'p1', layer: NetworkLayer.L2_ETHERNET, capacity: '40 Gbps', usage: 12 },
      { uuid: 'l3', sourceNodeUuid: 'd1', targetNodeUuid: 'd3', sourcePortUuid: 'eth1', targetPortUuid: 'p2', layer: NetworkLayer.L2_ETHERNET, capacity: '40 Gbps', usage: 80 },
      { uuid: 'ql1', sourceNodeUuid: 'q1', targetNodeUuid: 'q2', sourcePortUuid: 'q0', targetPortUuid: 'q0', layer: NetworkLayer.L0_OPTICAL, capacity: '1.2 Mbps', usage: 10 },
      { uuid: 'ql2', sourceNodeUuid: 'q2', targetNodeUuid: 'q3', sourcePortUuid: 'q1', targetPortUuid: 'q0', layer: NetworkLayer.L0_OPTICAL, capacity: '0.8 Mbps', usage: 0 }
    ];

    return { nodes, links };
  }

  public updateNodeGeoLocation(nodeUuid: string, locationObj: IETFGeoLocation) {
    const node = this.topology.nodes.find(n => n.uuid === nodeUuid);
    if (node) {
      node.ietfGeoLocation = locationObj;
    }
  }

  public updateComponentGeoLocation(nodeUuid: string, componentUuid: string, locationObj: IETFGeoLocation) {
    const node = this.topology.nodes.find(n => n.uuid === nodeUuid);
    if (node) {
      const comp = node.hardware.find(h => h.uuid === componentUuid);
      if (comp) {
        comp.ietfGeoLocation = locationObj;
      }
    }
  }

  // --- PASSIVE INVENTORY MANAGEMENT ---

  public getPassiveDevices(): PassiveDevice[] {
    return this.passiveDevices;
  }

  public addPassiveDevice(device: PassiveDevice): void {
    if (this.passiveDevices.some(d => d.id === device.id)) {
      throw new Error(`YANG Unique Constraint: Passive Device with ID '${device.id}' already exists.`);
    }
    this.passiveDevices.push(device);
  }

  public updatePassiveDevice(device: PassiveDevice): void {
    const idx = this.passiveDevices.findIndex(d => d.id === device.id);
    if (idx !== -1) {
      this.passiveDevices[idx] = device;
    }
  }

  public deletePassiveDevice(id: string): void {
    this.passiveDevices = this.passiveDevices.filter(d => d.id !== id);
  }

  public getPassiveCables(): PassiveCable[] {
    return this.passiveCables;
  }

  public addPassiveCable(cable: PassiveCable): void {
    if (this.passiveCables.some(c => c.id === cable.id)) {
      throw new Error(`YANG Unique Constraint: Cable with ID '${cable.id}' already exists.`);
    }
    this.passiveCables.push(cable);
  }

  public updatePassiveCable(cable: PassiveCable): void {
    const idx = this.passiveCables.findIndex(c => c.id === cable.id);
    if (idx !== -1) {
      this.passiveCables[idx] = cable;
    }
  }

  public deletePassiveCable(id: string): void {
    this.passiveCables = this.passiveCables.filter(c => c.id !== id);
  }

  private initializeDefaultPassiveInventory() {
    this.passiveDevices = [
      {
        id: 'odf-tokyo-otemachi-01',
        name: 'Otemachi Main Optical Distribution Frame (ODF)',
        deviceType: 'ODF',
        customTags: ['RFID-ODF-TK-102', 'BARCODE-994119'],
        locationRef: 'room-301-rack-R9D',
        passivePorts: [
          { id: 'port-1', portType: 'input-port', fiberCoreNum: 1 },
          { id: 'port-2', portType: 'output-port', fiberCoreNum: 2 },
          { id: 'port-3', portType: 'input-port', fiberCoreNum: 3 },
          { id: 'port-4', portType: 'output-port', fiberCoreNum: 4 },
          { id: 'port-5', portType: 'service-port', fiberCoreNum: 5 },
          { id: 'port-6', portType: 'service-port', fiberCoreNum: 6 },
          { id: 'port-7', portType: 'p2mp-port', fiberCoreNum: 7 },
          { id: 'port-8', portType: 'p2mp-port', fiberCoreNum: 8 }
        ]
      },
      {
        id: 'splitter-osaka-02',
        name: 'Osaka Chuo-ku passive optical splitter',
        deviceType: 'WDM',
        customTags: ['RFID-SPL-OS-554', 'QR-OSAKA-WDM-9'],
        locationRef: 'room-102-rack-OS-C',
        passivePorts: [
          { id: 'common-in', portType: 'input-port', fiberCoreNum: 1 },
          { id: 'ch-1550', portType: 'output-port', fiberCoreNum: 2 },
          { id: 'ch-1310', portType: 'output-port', fiberCoreNum: 3 },
          { id: 'ch-1490', portType: 'output-port', fiberCoreNum: 4 }
        ]
      },
      {
        id: 'fat-kozu-03',
        name: 'Kozu Beach Terminal Box (FAT)',
        deviceType: 'FAT',
        customTags: ['QR-KOZU-FAT-01'],
        locationRef: 'outdoor-enclosure-K3',
        passivePorts: [
          { id: 'feeder-1', portType: 'input-port', fiberCoreNum: 1 },
          { id: 'drop-1', portType: 'p2mp-port', fiberCoreNum: 2 },
          { id: 'drop-2', portType: 'p2mp-port', fiberCoreNum: 3 }
        ]
      }
    ];

    this.passiveCables = [
      {
        id: 'cable-tk-osa-backbone-01',
        name: 'Tokyo Otemachi to Osaka Chuo High-Capacity Trunk Cable',
        alias: 'TK-OSA-BAK-01',
        description: 'Primary trans-island passive underground optical fiber backbone cable.',
        cableType: 'optical-fiber',
        cableRole: 'backbone',
        length: 512000, // 512 km
        aEnd: {
          deviceType: 'active-device',
          neRef: 'node-TK1',
          componentRef: 'opt-1/1'
        },
        zEnd: {
          deviceType: 'active-device',
          neRef: 'node-OS1',
          componentRef: 'opt-1/1'
        },
        opticalCable: {
          fiberCoreNum: 192,
          fiberType: 'G652D',
          attenuation: 92.4
        }
      },
      {
        id: 'cable-segmented-tokyo-metro-02',
        name: 'Aoyama-Otemachi Spliced Concatenated Fiber Ring',
        alias: 'TK-METRO-CONCAT-02',
        description: 'A composite cable run linking NTT Otemachi main frame with Aoyama edge node through intermediate splicing points.',
        cableType: 'optical-fiber',
        cableRole: 'trunk',
        length: 15300,
        aEnd: {
          deviceType: 'active-device',
          neRef: 'node-TK1',
          componentRef: 'opt-1/2'
        },
        zEnd: {
          deviceType: 'passive-device',
          deviceId: 'odf-tokyo-otemachi-01'
        },
        opticalCable: {
          fiberCoreNum: 96,
          fiberType: 'G657A1',
          attenuation: 3.1
        },
        childCables: [
          { id: 'cable-segment-tokyo-otemachi-section-A', index: 1, length: 7300 },
          { id: 'cable-segment-tokyo-otemachi-section-B', index: 2, length: 8000 }
        ]
      },
      {
        id: 'cable-segment-tokyo-otemachi-section-A',
        name: 'Otemachi Section A Spliced segment',
        alias: 'TK-SEG-A',
        description: 'Underground conduit segment A from Otemachi core to Manhole #22.',
        cableType: 'optical-fiber',
        cableRole: 'distribution',
        length: 7300,
        aEnd: {
          deviceType: 'active-device',
          neRef: 'node-TK1'
        },
        zEnd: {
          deviceType: 'passive-device',
          deviceId: 'odf-tokyo-otemachi-01'
        },
        opticalCable: {
          fiberCoreNum: 96,
          fiberType: 'G652D',
          attenuation: 1.5
        }
      },
      {
        id: 'cable-segment-tokyo-otemachi-section-B',
        name: 'Otemachi Section B Spliced segment',
        alias: 'TK-SEG-B',
        description: 'Underground conduit segment B from Manhole #22 to Otemachi ODF frame.',
        cableType: 'optical-fiber',
        cableRole: 'distribution',
        length: 8000,
        aEnd: {
          deviceType: 'passive-device',
          deviceId: 'odf-tokyo-otemachi-01'
        },
        zEnd: {
          deviceType: 'active-device',
          neRef: 'node-TY1'
        },
        opticalCable: {
          fiberCoreNum: 96,
          fiberType: 'G652D',
          attenuation: 1.6
        }
      },
      {
        id: 'cable-coax-feed-04',
        name: 'Basestation Copper Coaxial Feeder Run',
        alias: 'BASE-COAX-4',
        description: 'Outdoor RG-11 Coaxial electrical run for local GPS clock distribution.',
        cableType: 'coaxial-cable',
        cableRole: 'branch',
        length: 85,
        aEnd: {
          deviceType: 'active-device',
          neRef: 'node-TK1'
        },
        zEnd: {
          deviceType: 'active-device',
          neRef: 'node-KOZU'
        }
      }
    ];
  }

  // --- BASE NETWORK TOPOLOGY (RFC 8345) MANAGEMENT ---

  public getRFC8345Networks(): RFC8345Network[] {
    return this.rfc8345Networks;
  }

  public addRFC8345Network(network: RFC8345Network): void {
    if (this.rfc8345Networks.some(n => n.networkId === network.networkId)) {
      throw new Error(`YANG Key Constraint: Network with ID '${network.networkId}' already exists.`);
    }

    // Run absolute RFC 8345 schema validation
    this.validateNetworkTopology(network);

    this.rfc8345Networks.push(network);
  }

  public updateRFC8345Network(network: RFC8345Network): void {
    const idx = this.rfc8345Networks.findIndex(n => n.networkId === network.networkId);
    if (idx !== -1) {
      // Run validation before committing
      this.validateNetworkTopology(network);
      this.rfc8345Networks[idx] = network;
    }
  }

  private validateNetworkTopology(network: RFC8345Network): void {
    // 1. Verify supporting-network references exist in database
    if (network.supportingNetworks) {
      for (const sn of network.supportingNetworks) {
        if (sn.networkRef === network.networkId) {
          throw new Error(`Self-reference Exception: A network cannot serve as an underlay for itself.`);
        }
        if (!this.rfc8345Networks.some(n => n.networkId === sn.networkRef)) {
          throw new Error(`Integrity Violation: Declared Supporting Network '${sn.networkRef}' does not exist.`);
        }
      }
    }

    // 2. Verify node and termination-point referential integrity
    for (const node of network.nodes) {
      // Uniqueness of tp-id inside node (Feature 29 / Scenario 1)
      if (node.terminationPoints) {
        const tpIds = new Set<string>();
        for (const tp of node.terminationPoints) {
          if (!tp.tpId.trim()) {
            throw new Error(`YANG Constraint Error: termination-point ID (tp-id) cannot be empty.`);
          }
          if (tpIds.has(tp.tpId)) {
            throw new Error(`YANG Key Constraint Violation: Duplicate termination-point ID '${tp.tpId}' configured under node '${node.nodeId}'.`);
          }
          tpIds.add(tp.tpId);

          // Verify supporting termination points (Use Case 16)
          if (tp.supportingTerminationPoints) {
            for (const stp of tp.supportingTerminationPoints) {
              const uNet = this.rfc8345Networks.find(rx => rx.networkId === stp.networkRef) || (stp.networkRef === network.networkId ? network : null);
              if (!uNet) {
                throw new Error(`Integrity Violation: Supporting TP under '${tp.tpId}' references non-existent network '${stp.networkRef}'.`);
              }
              const uNode = uNet.nodes.find(nx => nx.nodeId === stp.nodeRef);
              if (!uNode) {
                throw new Error(`Integrity Violation: Supporting TP under '${tp.tpId}' references non-existent node '${stp.nodeRef}' in network '${stp.networkRef}'.`);
              }
              const uTp = uNode.terminationPoints?.find(tx => tx.tpId === stp.tpRef);
              if (!uTp) {
                throw new Error(`Integrity Violation: Supporting TP under '${tp.tpId}' references non-existent TP '${stp.tpRef}' under node '${stp.nodeRef}' in network '${stp.networkRef}'.`);
              }
            }
          }
        }
      }

      // Supporting nodes
      if (node.supportingNodes) {
        for (const snode of node.supportingNodes) {
          const sn = this.rfc8345Networks.find(n => n.networkId === snode.networkRef) || (snode.networkRef === network.networkId ? network : null);
          if (!sn) {
            throw new Error(`Integrity Violation: Node '${node.nodeId}' references non-existent supporting-network '${snode.networkRef}'.`);
          }
          if (!sn.nodes.some(n => n.nodeId === snode.nodeRef)) {
            throw new Error(`Integrity Violation: Node '${node.nodeId}' references non-existent supporting-node '${snode.nodeRef}' in network '${snode.networkRef}'.`);
          }
        }
      }
    }

    // 3. Verify Links reference integrity (Use Case 14)
    if (network.links) {
      const linkIds = new Set<string>();
      for (const link of network.links) {
        if (!link.linkId.trim()) {
          throw new Error(`YANG Constraint Error: Link ID (link-id) cannot be empty.`);
        }
        if (linkIds.has(link.linkId)) {
          throw new Error(`YANG Key Constraint Violation: Duplicate link ID '${link.linkId}' configured inside network '${network.networkId}'.`);
        }
        linkIds.add(link.linkId);

        // Verify source-node and source-tp
        const srcNode = network.nodes.find(n => n.nodeId === link.source.sourceNode);
        if (!srcNode) {
          throw new Error(`Integrity Violation: Link '${link.linkId}' source-node '${link.source.sourceNode}' does not exist inside network '${network.networkId}'.`);
        }
        const srcTp = srcNode.terminationPoints?.find(tp => tp.tpId === link.source.sourceTp);
        if (!srcTp) {
          throw new Error(`Integrity Violation: Link '${link.linkId}' source-tp '${link.source.sourceTp}' does not exist under node '${link.source.sourceNode}'.`);
        }

        // Verify dest-node and dest-tp
        const destNode = network.nodes.find(n => n.nodeId === link.destination.destNode);
        if (!destNode) {
          throw new Error(`Integrity Violation: Link '${link.linkId}' dest-node '${link.destination.destNode}' does not exist inside network '${network.networkId}'.`);
        }
        const destTp = destNode.terminationPoints?.find(tp => tp.tpId === link.destination.destTp);
        if (!destTp) {
          throw new Error(`Integrity Violation: Link '${link.linkId}' dest-tp '${link.destination.destTp}' does not exist under node '${link.destination.destNode}'.`);
        }

        // Verify supporting links
        if (link.supportingLinks) {
          for (const sl of link.supportingLinks) {
            const uNet = this.rfc8345Networks.find(rx => rx.networkId === sl.networkRef) || (sl.networkRef === network.networkId ? network : null);
            if (!uNet) {
              throw new Error(`Integrity Violation: Supporting link of '${link.linkId}' references non-existent network '${sl.networkRef}'.`);
            }
            const uLink = uNet.links?.find(lx => lx.linkId === sl.linkRef);
            if (!uLink) {
              throw new Error(`Integrity Violation: Supporting link of '${link.linkId}' references non-existent link '${sl.linkRef}' in network '${sl.networkRef}'.`);
            }
          }
        }

        // Cycle analysis to prevent reference loops (US 34)
        this.detectLinkCycle(link.linkId, link.supportingLinks, new Set<string>(), network);
      }
    }
  }

  private detectLinkCycle(
    targetLinkId: string,
    supportingLinks: SupportingLink[] | undefined,
    visited: Set<string>,
    currentNet: RFC8345Network
  ): void {
    if (!supportingLinks) return;
    for (const sl of supportingLinks) {
      const key = `${sl.networkRef}:${sl.linkRef}`;
      if (sl.linkRef === targetLinkId) {
        throw new Error(`Integrity Exception: Reference loop detected! Link '${targetLinkId}' directly or transitively depends on itself.`);
      }
      if (visited.has(key)) {
        continue;
      }
      visited.add(key);

      // Find inside existing database or current draft network
      const sn = this.rfc8345Networks.find(nx => nx.networkId === sl.networkRef) || (sl.networkRef === currentNet.networkId ? currentNet : null);
      if (sn) {
        const supportingLinkObj = sn.links?.find(l => l.linkId === sl.linkRef);
        if (supportingLinkObj) {
          this.detectLinkCycle(targetLinkId, supportingLinkObj.supportingLinks, visited, currentNet);
        }
      }
    }
  }

  public deleteRFC8345Network(networkId: string): void {
    const referencers = this.rfc8345Networks.filter(n => n.supportingNetworks?.some(sn => sn.networkRef === networkId));
    if (referencers.length > 0) {
      throw new Error(`Dependency Error: Cannot delete network '${networkId}' as it is currently serving as an underlay for: ${referencers.map(r => r.networkId).join(', ')}.`);
    }
    this.rfc8345Networks = this.rfc8345Networks.filter(n => n.networkId !== networkId);
  }

  private initializeDefaultBaseNetworks() {
    this.rfc8345Networks = [
      {
         networkId: 'underlay-L0',
         name: 'L0 Physical Optical Underlay',
         description: 'Underlying trans-island physical fiber cabling, optical wave multiplexers and active terminals.',
         networkTypes: {
           type: 'physical'
         },
         nodes: [
           {
             nodeId: 'node-L0-TK-terminal',
             name: 'Tokyo Otemachi L0 Terminal',
             description: 'Physical multi-wavelength transponder with dense wavelength division multiplexing (DWDM) filters.',
             activeNeRef: 'node-TK1',
             chassis: {
               chassisId: 'ch-TK1',
               name: 'TK1-Chassis',
               manufacturer: 'Ciena Corporation',
               partNumber: 'NTK503KA',
               serialNumber: 'CN-CH-TK1-001',
               status: 'active',
               isMain: true,
               alias: 'TK1-OPT-CORE-PRIMARY-CHASSIS',
               description: 'Active Ciena 6500 packet-optical main chassis in Otemachi Rack R9D',
               hardwareRev: '6500-T12-REV3',
               mfgDate: '2025-02-12T08:00:00Z',
               assetId: 'ASSET-CIENA-TK1-1A'
             },
             modules: [
               {
                 uuid: 'mod-TK1-1',
                 name: 'WaveLogic-5-Extreme',
                 class: 'module',
                 parentUuid: 'ch-TK1',
                 manufacturer: 'Ciena Corporation',
                 partNumber: 'NTK540EC',
                 serialNumber: 'CN-MOD-TK1-W5E',
                 status: 'active',
                 alias: 'W5E-LINE-CARD-1',
                 hardwareRev: 'WL5E-HW-1.2',
                 mfgDate: '2025-03-30T10:00:00Z'
               }
             ],
             gridConfig: {
               gridType: 'wson-grid-dwdm',
               priority: 7,
               dwdmSpacing: 'dwdm-50ghz',
               dwdmN: 2,
               centralFrequencyGhz: 193200.0,
               slotWidthGhz: 50.0
             },
             terminationPoints: [
               {
                 tpId: 'tp-L0-TK-out',
                 activePortRef: 'port-TK1-1',
                 opticalChannelFreqGhz: 193200.0,
                 transceiver: {
                   uuid: 'tcvr-TK1-1',
                   name: '800G-ZR-Optic',
                   manufacturer: 'Ciena Corporation',
                   partNumber: 'NTK-800G-ZR',
                   serialNumber: 'CN-TCV-TK1-1',
                   status: 'active',
                   alias: 'XCVR-PORT-1-800G',
                   description: 'Coherent 800G long-haul transceiver module',
                   hardwareRev: 'ZR-REV2',
                   mfgDate: '2025-04-10T11:30:00Z'
                 }
               },
               {
                 tpId: 'tp-L0-TK-in',
                 activePortRef: 'port-TK1-2',
                 opticalChannelFreqGhz: 193250.0,
                 transceiver: {
                   uuid: 'tcvr-TK1-2',
                   name: '800G-ZR-Optic',
                   manufacturer: 'Ciena Corporation',
                   partNumber: 'NTK-800G-ZR',
                   serialNumber: 'CN-TCV-TK1-2',
                   status: 'active',
                   alias: 'XCVR-PORT-2-800G',
                   description: 'Coherent 800G transceiver receiver',
                   hardwareRev: 'ZR-REV2',
                   mfgDate: '2025-04-10T11:30:00Z'
                 }
               }
             ]
           },
           {
             nodeId: 'node-L0-OS-terminal',
             name: 'Osaka Chuo L0 Terminal',
             description: 'Physical transponder housing C-band multiplexing elements connecting regional optical trunk fibers.',
             activeNeRef: 'node-OS1',
             chassis: {
               chassisId: 'ch-OS1',
               name: 'OS1-Chassis',
               manufacturer: 'Ciena Corporation',
               partNumber: 'NTK503KA',
               serialNumber: 'CN-CH-OS1-001',
               status: 'active',
               isMain: true,
               alias: 'OS1-PRIMARY-OPTICAL-FRAME',
               description: 'Active Ciena 6500 packet-optical main chassis in Osaka Central',
               hardwareRev: '6500-T12-REV3',
               mfgDate: '2025-02-15T09:00:00Z',
               assetId: 'ASSET-CIENA-OS1-1A'
             },
             modules: [
               {
                 uuid: 'mod-OS1-1',
                 name: 'WaveLogic-5-Extreme',
                 class: 'module',
                 parentUuid: 'ch-OS1',
                 manufacturer: 'Ciena Corporation',
                 partNumber: 'NTK540EC',
                 serialNumber: 'CN-MOD-OS1-W5E',
                 status: 'active',
                 alias: 'W5E-LINE-CARD-OS1',
                 hardwareRev: 'WL5E-HW-1.2',
                 mfgDate: '2025-03-31T10:00:00Z'
               }
             ],
             gridConfig: {
               gridType: 'wson-grid-dwdm',
               priority: 7,
               dwdmSpacing: 'dwdm-50ghz',
               dwdmN: 2,
               centralFrequencyGhz: 193200.0,
               slotWidthGhz: 50.0
             },
             terminationPoints: [
               {
                 tpId: 'tp-L0-OS-in',
                 activePortRef: 'port-OS1-1',
                 opticalChannelFreqGhz: 193200.0,
                 transceiver: {
                   uuid: 'tcvr-OS1-1',
                   name: '800G-ZR-Optic',
                   manufacturer: 'Ciena Corporation',
                   partNumber: 'NTK-800G-ZR',
                   serialNumber: 'CN-TCV-OS1-1',
                   status: 'active',
                   alias: 'XCVR-OS-IN',
                   description: 'Coherent 800G Receiver',
                   hardwareRev: 'ZR-REV2',
                   mfgDate: '2025-04-12T10:00:00Z'
                 }
               },
               {
                 tpId: 'tp-L0-OS-out',
                 activePortRef: 'port-OS1-2',
                 opticalChannelFreqGhz: 193250.0,
                 transceiver: {
                   uuid: 'tcvr-OS1-2',
                   name: '800G-ZR-Optic',
                   manufacturer: 'Ciena Corporation',
                   partNumber: 'NTK-800G-ZR',
                   serialNumber: 'CN-TCV-OS1-2',
                   status: 'active',
                   alias: 'XCVR-OS-OUT',
                   description: 'Coherent 800G Transmitter',
                   hardwareRev: 'ZR-REV2',
                   mfgDate: '2025-04-12T10:00:00Z'
                 }
               }
             ]
           },
           {
             nodeId: 'node-L0-TYO-router-chassis',
             name: 'Tokyo-Toyosu Physical Frame',
             description: 'Fiber distribution frame slot housing physical transceiver connections.',
             activeNeRef: 'node-TY1',
             chassis: {
               chassisId: 'ch-TY1',
               name: 'TY1-Chassis',
               manufacturer: 'Ciena Corporation',
               partNumber: 'NTK320CD',
               serialNumber: 'CN-CH-TY1-002',
               status: 'active',
               isMain: true,
               alias: 'TOYOSU-EDGE-OPTICAL-FRAME',
               description: 'Active Ciena chassis at Toyosu Tokyo DC',
               hardwareRev: '6500-T6-REV1',
               mfgDate: '2025-06-18T14:00:00Z',
               assetId: 'ASSET-CIENA-TY1-3B'
             },
             modules: [
               {
                 uuid: 'mod-TY1-1',
                 name: 'WaveLogic-5-Extreme',
                 class: 'module',
                 parentUuid: 'ch-TY1',
                 manufacturer: 'Ciena Corporation',
                 partNumber: 'NTK540EC',
                 serialNumber: 'CN-MOD-TY1-W5E',
                 status: 'active',
                 alias: 'W5E-LINE-CARD-TY1',
                 hardwareRev: 'WL5E-HW-1.2',
                 mfgDate: '2025-07-02T09:00:00Z'
               }
             ],
             gridConfig: {
               gridType: 'wson-grid-dwdm',
               priority: 7,
               dwdmSpacing: 'dwdm-50ghz',
               dwdmN: 3,
               centralFrequencyGhz: 193250.0,
               slotWidthGhz: 50.0
             },
             terminationPoints: [
               {
                 tpId: 'tp-L0-TYO-slot1',
                 activePortRef: 'port-TY1-1',
                 opticalChannelFreqGhz: 193300.0,
                 transceiver: {
                   uuid: 'tcvr-TY1-1',
                   name: '800G-ZR-Optic',
                   manufacturer: 'Ciena Corporation',
                   partNumber: 'NTK-800G-ZR',
                   serialNumber: 'CN-TCV-TY1-1',
                   status: 'active',
                   alias: 'XCVR-TYO-PORT1',
                   description: 'Coherent 800G line card channel transceiver',
                   hardwareRev: 'ZR-REV2',
                   mfgDate: '2025-07-05T12:00:00Z'
                 }
               }
             ]
           }
         ],
         links: [
           {
             linkId: 'link-L0-TK-to-OS',
             source: {
               sourceNode: 'node-L0-TK-terminal',
               sourceTp: 'tp-L0-TK-out'
             },
             destination: {
               destNode: 'node-L0-OS-terminal',
               destTp: 'tp-L0-OS-in'
             }
           },
           {
             linkId: 'link-L0-OS-to-TK',
             source: {
               sourceNode: 'node-L0-OS-terminal',
               sourceTp: 'tp-L0-OS-out'
             },
             destination: {
               destNode: 'node-L0-TK-terminal',
               destTp: 'tp-L0-TK-in'
             }
           }
         ]
       },
       {
         networkId: 'overlay-L3',
         name: 'L3 IP Carrier Overlay Network',
         description: 'Logical IP routing overlay layer supported by the trans-island optical transport layer wavelengths.',
         networkTypes: {
           type: 'L3-ip-overlay'
         },
         supportingNetworks: [
           { networkRef: 'underlay-L0' }
         ],
         nodes: [
           {
             nodeId: 'node-L3-TK-router',
             name: 'Tokyo IP Core Router',
             description: 'Carrier-grade routing platform with L3 logical IP interfaces mapped to physical transceiver frames.',
             supportingNodes: [
               { networkRef: 'underlay-L0', nodeRef: 'node-L0-TK-terminal' }
             ],
             terminationPoints: [
               {
                 tpId: 'tp-L3-TK-ge1',
                 supportingTerminationPoints: [
                   { networkRef: 'underlay-L0', nodeRef: 'node-L0-TK-terminal', tpRef: 'tp-L0-TK-out' }
                 ]
               },
               {
                 tpId: 'tp-L3-TK-ge2',
                 supportingTerminationPoints: [
                   { networkRef: 'underlay-L0', nodeRef: 'node-L0-TK-terminal', tpRef: 'tp-L0-TK-in' }
                 ]
               }
             ]
           },
           {
             nodeId: 'node-L3-OS-router',
             name: 'Osaka IP Core Router',
             description: 'Carrier-grade routing platform with high-capacity interfaces terminating central trans-island logical links.',
             supportingNodes: [
               { networkRef: 'underlay-L0', nodeRef: 'node-L0-OS-terminal' }
             ],
             terminationPoints: [
               {
                 tpId: 'tp-L3-OS-ge1',
                 supportingTerminationPoints: [
                   { networkRef: 'underlay-L0', nodeRef: 'node-L0-OS-terminal', tpRef: 'tp-L0-OS-in' }
                 ]
               },
               {
                 tpId: 'tp-L3-OS-ge2',
                 supportingTerminationPoints: [
                   { networkRef: 'underlay-L0', nodeRef: 'node-L0-OS-terminal', tpRef: 'tp-L0-OS-out' }
                 ]
               }
             ]
           }
         ],
         links: [
           {
             linkId: 'link-L3-TK-to-OS',
             source: {
               sourceNode: 'node-L3-TK-router',
               sourceTp: 'tp-L3-TK-ge1'
             },
             destination: {
               destNode: 'node-L3-OS-router',
               destTp: 'tp-L3-OS-ge1'
             },
             supportingLinks: [
               { networkRef: 'underlay-L0', linkRef: 'link-L0-TK-to-OS' }
             ]
           },
           {
             linkId: 'link-L3-OS-to-TK',
             source: {
               sourceNode: 'node-L3-OS-router',
               sourceTp: 'tp-L3-OS-ge2'
             },
             destination: {
               destNode: 'node-L3-TK-router',
               destTp: 'tp-L3-TK-ge2'
             },
             supportingLinks: [
               { networkRef: 'underlay-L0', linkRef: 'link-L0-OS-to-TK' }
             ]
           }
         ]
       },
       {
         networkId: 'underlay-OTN-L1',
         name: 'OTN & fg-OTN Transport Network',
         description: 'Layer 1 Optical Transport Network (OTN) conforming to ietf-otn-topology and ietf-fgotn-topology (Draft-IETF-ccamp-otn-topo-yang).',
         networkTypes: {
           type: 'L1-transport'
         },
         otnTopology: true,
         supportingNetworks: [
           { networkRef: 'underlay-L0' }
         ],
         nodes: [
           {
             nodeId: 'node-OTN-TK-card',
             name: 'Tokyo OTN/fg-OTN Transport Card',
             description: 'OTN G.709 transport card supporting sub-1G fine-grained timeslot slicing.',
             supportingNodes: [
               { networkRef: 'underlay-L0', nodeRef: 'node-L0-TK-terminal' }
             ],
             otnNode: { presence: true },
             terminationPoints: [
               {
                 tpId: 'tp-OTN-TK-port1',
                 supportingTerminationPoints: [
                   { networkRef: 'underlay-L0', nodeRef: 'node-L0-TK-terminal', tpRef: 'tp-L0-TK-out' }
                 ],
                 otnLinkTp: {
                   tsg: 'tsg-1.25G',
                   supportedClientSignal: [
                     { clientSignal: 'iana-if-type:ethernetCsmacd' },
                     { clientSignal: 'client-signal:OTU2' }
                   ]
                 }
               }
             ]
           },
           {
             nodeId: 'node-OTN-OS-card',
             name: 'Osaka OTN/fg-OTN Transport Card',
             description: 'OTN G.709 transport card supporting sub-1G fine-grained timeslot slicing.',
             supportingNodes: [
               { networkRef: 'underlay-L0', nodeRef: 'node-L0-OS-terminal' }
             ],
             otnNode: { presence: true },
             terminationPoints: [
               {
                 tpId: 'tp-OTN-OS-port1',
                 supportingTerminationPoints: [
                   { networkRef: 'underlay-L0', nodeRef: 'node-L0-OS-terminal', tpRef: 'tp-L0-OS-in' }
                 ],
                 otnLinkTp: {
                   tsg: 'tsg-1.25G',
                   supportedClientSignal: [
                     { clientSignal: 'iana-if-type:ethernetCsmacd' },
                     { clientSignal: 'client-signal:OTU2' }
                   ]
                 }
               }
             ]
           }
         ],
         links: [
           {
             linkId: 'link-OTN-TK-to-OS',
             source: {
               sourceNode: 'node-OTN-TK-card',
               sourceTp: 'tp-OTN-TK-port1'
             },
             destination: {
               destNode: 'node-OTN-OS-card',
               destTp: 'tp-OTN-OS-port1'
             },
             supportingLinks: [
               { networkRef: 'underlay-L0', linkRef: 'link-L0-TK-to-OS' }
             ],
             otnLink: {
               distance: 512
             },
             fgotnList: [
               {
                 oduType: 'fgODUflex',
                 oduTsNumber: '1-10',
                 fgotnBandwidth: 100
               },
               {
                 oduType: 'fgODUflex',
                 oduTsNumber: '11-15',
                 fgotnBandwidth: 50
               }
             ],
             fgtsRange: [
               {
                 oduType: 'fgODUflex',
                 oduTsNumber: '1-80',
                 fgtsReserved: '1-15',
                 fgtsUnreserved: '16-80'
              }
             ]
           }
         ]
       }
    ];
  }
}
