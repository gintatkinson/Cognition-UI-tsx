
import { NetworkTopology, NetworkElement, NetworkLink, NetworkLayer } from '../types';

export function getJapaneseOpticalTopology(): NetworkTopology {
    return {
        nodes: [
    {
        "uuid": "CU-node-TK1",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-tk1",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-12",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.6881,
                    "longitude": 139.7635,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 108780132,
                    "inUnicastPkts": 72734,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 108630875,
                    "outUnicastPkts": 72430,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 672939088,
                    "inUnicastPkts": 448793,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 672990571,
                    "outUnicastPkts": 449003,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 11435430,
                    "inUnicastPkts": 8215,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 11539297,
                    "outUnicastPkts": 7955,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 9240894,
                    "inUnicastPkts": 6739,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 9046838,
                    "outUnicastPkts": 6025,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-TK1",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "NEC Corporation",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-6492",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-TK1",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-tk1",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-12",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.6881,
                    "longitude": 139.7635,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 108780132,
                    "inUnicastPkts": 72734,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 108630875,
                    "outUnicastPkts": 72430,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 672939088,
                    "inUnicastPkts": 448793,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 672990571,
                    "outUnicastPkts": 449003,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 11435430,
                    "inUnicastPkts": 8215,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 11539297,
                    "outUnicastPkts": 7955,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 9240894,
                    "inUnicastPkts": 6739,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 9046838,
                    "outUnicastPkts": 6025,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-TK1",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-6501",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-TH_OTE",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-th_ote",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-50",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.6885,
                    "longitude": 139.763,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 874270920,
                    "inUnicastPkts": 582606,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 874321715,
                    "outUnicastPkts": 583376,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 573430001,
                    "inUnicastPkts": 382806,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 573409492,
                    "outUnicastPkts": 382846,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 827474076,
                    "inUnicastPkts": 552550,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 827632024,
                    "outUnicastPkts": 552142,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 115463546,
                    "inUnicastPkts": 77344,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 115108747,
                    "outUnicastPkts": 77295,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-TH_OTE",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "Fujitsu",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-514",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-TH_OTE",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-th_ote",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-50",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.6885,
                    "longitude": 139.763,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 874270920,
                    "inUnicastPkts": 582606,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 874321715,
                    "outUnicastPkts": 583376,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 573430001,
                    "inUnicastPkts": 382806,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 573409492,
                    "outUnicastPkts": 382846,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 827474076,
                    "inUnicastPkts": 552550,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 827632024,
                    "outUnicastPkts": 552142,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 115463546,
                    "inUnicastPkts": 77344,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 115108747,
                    "outUnicastPkts": 77295,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-TH_OTE",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-3681",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-TY1",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-ty1",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-45",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.5828,
                    "longitude": 139.7424,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 846864912,
                    "inUnicastPkts": 564870,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 846983421,
                    "outUnicastPkts": 565013,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 142042574,
                    "inUnicastPkts": 95170,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 142369311,
                    "outUnicastPkts": 94880,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 716073238,
                    "inUnicastPkts": 477691,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 716015037,
                    "outUnicastPkts": 478174,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 272367635,
                    "inUnicastPkts": 181754,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 272221153,
                    "outUnicastPkts": 181539,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-TY1",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "Rakuten Symphony",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-7173",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-TY1",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-ty1",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-45",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.5828,
                    "longitude": 139.7424,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 846864912,
                    "inUnicastPkts": 564870,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 846983421,
                    "outUnicastPkts": 565013,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 142042574,
                    "inUnicastPkts": 95170,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 142369311,
                    "outUnicastPkts": 94880,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 716073238,
                    "inUnicastPkts": 477691,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 716015037,
                    "outUnicastPkts": 478174,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 272367635,
                    "inUnicastPkts": 181754,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 272221153,
                    "outUnicastPkts": 181539,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-TY1",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-5853",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-CC1",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-cc1",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-7",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.6531,
                    "longitude": 139.7963,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 786931529,
                    "inUnicastPkts": 525207,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 787129019,
                    "outUnicastPkts": 525255,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 95725735,
                    "inUnicastPkts": 64248,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 96050609,
                    "outUnicastPkts": 63961,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 459117737,
                    "inUnicastPkts": 306949,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 459327461,
                    "outUnicastPkts": 306833,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 244577470,
                    "inUnicastPkts": 163547,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 244752302,
                    "outUnicastPkts": 163792,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-CC1",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "NEC Corporation",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-9601",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-CC1",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-cc1",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-7",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.6531,
                    "longitude": 139.7963,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 786931529,
                    "inUnicastPkts": 525207,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 787129019,
                    "outUnicastPkts": 525255,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 95725735,
                    "inUnicastPkts": 64248,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 96050609,
                    "outUnicastPkts": 63961,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 459117737,
                    "inUnicastPkts": 306949,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 459327461,
                    "outUnicastPkts": 306833,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 244577470,
                    "inUnicastPkts": 163547,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 244752302,
                    "outUnicastPkts": 163792,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-CC1",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-1431",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-FUJI_SUMMIT",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "Mount Fuji",
        "ietfSystem": {
            "hostname": "cu-node-fuji_summit",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "Mt. Fuji Summit Observatory",
            "buildingOrHut": "Telecom Hut Alpha",
            "rackIdentifier": "Rack-1",
            "rackPosition": 22,
            "notes": "Telco hut co-locates 3 additional empty/third-party racks."
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.3606,
                    "longitude": 138.7274,
                    "height": 3776
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 481819442,
                    "inUnicastPkts": 321110,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 481826408,
                    "outUnicastPkts": 321076,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 305584116,
                    "inUnicastPkts": 203888,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 305582219,
                    "outUnicastPkts": 204359,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 706733691,
                    "inUnicastPkts": 471511,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 706563500,
                    "outUnicastPkts": 471203,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 953461777,
                    "inUnicastPkts": 636090,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 953303764,
                    "outUnicastPkts": 635511,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-FUJI_SUMMIT",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "Fujitsu",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-6893",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-FUJI_SUMMIT",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "Mount Fuji",
        "ietfSystem": {
            "hostname": "terrabeam-node-fuji_summit",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "Mt. Fuji Summit Observatory",
            "buildingOrHut": "Telecom Hut Alpha",
            "rackIdentifier": "Rack-1",
            "rackPosition": 22,
            "notes": "Telco hut co-locates 3 additional empty/third-party racks."
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.3606,
                    "longitude": 138.7274,
                    "height": 3776
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 481819442,
                    "inUnicastPkts": 321110,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 481826408,
                    "outUnicastPkts": 321076,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 305584116,
                    "inUnicastPkts": 203888,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 305582219,
                    "outUnicastPkts": 204359,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 706733691,
                    "inUnicastPkts": 471511,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 706563500,
                    "outUnicastPkts": 471203,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 953461777,
                    "inUnicastPkts": 636090,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 953303764,
                    "outUnicastPkts": 635511,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-FUJI_SUMMIT",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-8348",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-TYO2",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-tyo2",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-12",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 36.2333,
                    "longitude": 137.65,
                    "height": 2500
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 584278247,
                    "inUnicastPkts": 389753,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 584329599,
                    "outUnicastPkts": 389923,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 436000390,
                    "inUnicastPkts": 291369,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 436108227,
                    "outUnicastPkts": 291563,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 484826595,
                    "inUnicastPkts": 323330,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 484863964,
                    "outUnicastPkts": 323077,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 555405474,
                    "inUnicastPkts": 370365,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 555646535,
                    "outUnicastPkts": 370464,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-TYO2",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "Rakuten Symphony",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-2009",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-TYO2",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-tyo2",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-12",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 36.2333,
                    "longitude": 137.65,
                    "height": 2500
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 584278247,
                    "inUnicastPkts": 389753,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 584329599,
                    "outUnicastPkts": 389923,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 436000390,
                    "inUnicastPkts": 291369,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 436108227,
                    "outUnicastPkts": 291563,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 484826595,
                    "inUnicastPkts": 323330,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 484863964,
                    "outUnicastPkts": 323077,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 555405474,
                    "inUnicastPkts": 370365,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 555646535,
                    "outUnicastPkts": 370464,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-TYO2",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-7571",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-M_CLS",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-m_cls",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-42",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.0392,
                    "longitude": 139.9928,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 201430344,
                    "inUnicastPkts": 134862,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 201481926,
                    "outUnicastPkts": 134725,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 783029569,
                    "inUnicastPkts": 521954,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 782911387,
                    "outUnicastPkts": 521737,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 234349581,
                    "inUnicastPkts": 156922,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 234525212,
                    "outUnicastPkts": 157059,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 801942985,
                    "inUnicastPkts": 534871,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 801833375,
                    "outUnicastPkts": 535134,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-M_CLS",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "NEC Corporation",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-7173",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-M_CLS",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-m_cls",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-42",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.0392,
                    "longitude": 139.9928,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 201430344,
                    "inUnicastPkts": 134862,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 201481926,
                    "outUnicastPkts": 134725,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 783029569,
                    "inUnicastPkts": 521954,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 782911387,
                    "outUnicastPkts": 521737,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 234349581,
                    "inUnicastPkts": 156922,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 234525212,
                    "outUnicastPkts": 157059,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 801942985,
                    "inUnicastPkts": 534871,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 801833375,
                    "outUnicastPkts": 535134,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-M_CLS",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-5959",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-OS1",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-os1",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-14",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.6961,
                    "longitude": 135.495,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 432380504,
                    "inUnicastPkts": 288715,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 432611305,
                    "outUnicastPkts": 288414,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 631319636,
                    "inUnicastPkts": 421556,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 631305326,
                    "outUnicastPkts": 420949,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 35572355,
                    "inUnicastPkts": 24434,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 35544589,
                    "outUnicastPkts": 23922,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 927629633,
                    "inUnicastPkts": 618515,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 928015306,
                    "outUnicastPkts": 619317,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-OS1",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "Fujitsu",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-885",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-OS1",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-os1",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-14",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.6961,
                    "longitude": 135.495,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 432380504,
                    "inUnicastPkts": 288715,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 432611305,
                    "outUnicastPkts": 288414,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 631319636,
                    "inUnicastPkts": 421556,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 631305326,
                    "outUnicastPkts": 420949,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 35572355,
                    "inUnicastPkts": 24434,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 35544589,
                    "outUnicastPkts": 23922,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 927629633,
                    "inUnicastPkts": 618515,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 928015306,
                    "outUnicastPkts": 619317,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-OS1",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-3014",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-OS3",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-os3",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-48",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.6963,
                    "longitude": 135.4952,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 447354386,
                    "inUnicastPkts": 298472,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 447500022,
                    "outUnicastPkts": 298347,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 785778435,
                    "inUnicastPkts": 524112,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 785878472,
                    "outUnicastPkts": 524188,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 907173512,
                    "inUnicastPkts": 605270,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 907088402,
                    "outUnicastPkts": 605470,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 698444467,
                    "inUnicastPkts": 466166,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 698049457,
                    "outUnicastPkts": 466080,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-OS3",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "Rakuten Symphony",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-6495",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-OS3",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-os3",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-48",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.6963,
                    "longitude": 135.4952,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 447354386,
                    "inUnicastPkts": 298472,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 447500022,
                    "outUnicastPkts": 298347,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 785778435,
                    "inUnicastPkts": 524112,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 785878472,
                    "outUnicastPkts": 524188,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 907173512,
                    "inUnicastPkts": 605270,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 907088402,
                    "outUnicastPkts": 605470,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 698444467,
                    "inUnicastPkts": 466166,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 698049457,
                    "outUnicastPkts": 466080,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-OS3",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-6701",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-DC12",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-dc12",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-13",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.696,
                    "longitude": 135.4955,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 828281857,
                    "inUnicastPkts": 552116,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 828384542,
                    "outUnicastPkts": 552449,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 217281741,
                    "inUnicastPkts": 144831,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 217222727,
                    "outUnicastPkts": 145108,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 705293526,
                    "inUnicastPkts": 470552,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 705333437,
                    "outUnicastPkts": 470665,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 534204949,
                    "inUnicastPkts": 356740,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 534496542,
                    "outUnicastPkts": 356348,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-DC12",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "NEC Corporation",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-8911",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-DC12",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-dc12",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-13",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.696,
                    "longitude": 135.4955,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 828281857,
                    "inUnicastPkts": 552116,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 828384542,
                    "outUnicastPkts": 552449,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 217281741,
                    "inUnicastPkts": 144831,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 217222727,
                    "outUnicastPkts": 145108,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 705293526,
                    "inUnicastPkts": 470552,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 705333437,
                    "outUnicastPkts": 470665,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 534204949,
                    "inUnicastPkts": 356740,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 534496542,
                    "outUnicastPkts": 356348,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-DC12",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-6954",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-EQ_OS1",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-eq_os1",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-5",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.6763,
                    "longitude": 135.4947,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 243704328,
                    "inUnicastPkts": 163176,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 244032027,
                    "outUnicastPkts": 162835,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 612780665,
                    "inUnicastPkts": 408801,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 612883052,
                    "outUnicastPkts": 408652,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 433366743,
                    "inUnicastPkts": 289606,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 433357363,
                    "outUnicastPkts": 289459,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 505544619,
                    "inUnicastPkts": 337195,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 505856082,
                    "outUnicastPkts": 337351,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-EQ_OS1",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "Fujitsu",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-6529",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-EQ_OS1",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-eq_os1",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-5",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.6763,
                    "longitude": 135.4947,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 243704328,
                    "inUnicastPkts": 163176,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 244032027,
                    "outUnicastPkts": 162835,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 612780665,
                    "inUnicastPkts": 408801,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 612883052,
                    "outUnicastPkts": 408652,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 433366743,
                    "inUnicastPkts": 289606,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 433357363,
                    "outUnicastPkts": 289459,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 505544619,
                    "inUnicastPkts": 337195,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 505856082,
                    "outUnicastPkts": 337351,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-EQ_OS1",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-4311",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-KOZU",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-kozu",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-8",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.6677,
                    "longitude": 135.5113,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 408923308,
                    "inUnicastPkts": 272691,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 408659238,
                    "outUnicastPkts": 272667,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 660544307,
                    "inUnicastPkts": 440676,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 660452098,
                    "outUnicastPkts": 440310,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 623494047,
                    "inUnicastPkts": 415793,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 623366305,
                    "outUnicastPkts": 416546,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 685845210,
                    "inUnicastPkts": 458014,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 685800749,
                    "outUnicastPkts": 457537,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-KOZU",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "Rakuten Symphony",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-3625",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-KOZU",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-kozu",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-8",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.6677,
                    "longitude": 135.5113,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 408923308,
                    "inUnicastPkts": 272691,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 408659238,
                    "outUnicastPkts": 272667,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 660544307,
                    "inUnicastPkts": 440676,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 660452098,
                    "outUnicastPkts": 440310,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 623494047,
                    "inUnicastPkts": 415793,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 623366305,
                    "outUnicastPkts": 416546,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 685845210,
                    "inUnicastPkts": 458014,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 685800749,
                    "outUnicastPkts": 457537,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-KOZU",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-4397",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-SP_OD",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-sp_od",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-38",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 43.0618,
                    "longitude": 141.3545,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 26444450,
                    "inUnicastPkts": 18476,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 26283626,
                    "outUnicastPkts": 18340,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 616525461,
                    "inUnicastPkts": 411681,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 616224227,
                    "outUnicastPkts": 411133,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 170049552,
                    "inUnicastPkts": 113701,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 170118002,
                    "outUnicastPkts": 113950,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 301108843,
                    "inUnicastPkts": 201325,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 301485949,
                    "outUnicastPkts": 200678,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-SP_OD",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "NEC Corporation",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-6949",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-SP_OD",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-sp_od",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-38",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 43.0618,
                    "longitude": 141.3545,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 26444450,
                    "inUnicastPkts": 18476,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 26283626,
                    "outUnicastPkts": 18340,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 616525461,
                    "inUnicastPkts": 411681,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 616224227,
                    "outUnicastPkts": 411133,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 170049552,
                    "inUnicastPkts": 113701,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 170118002,
                    "outUnicastPkts": 113950,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 301108843,
                    "inUnicastPkts": 201325,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 301485949,
                    "outUnicastPkts": 200678,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-SP_OD",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-8425",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-SD_CH",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-sd_ch",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-20",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 38.2682,
                    "longitude": 140.8694,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 218035067,
                    "inUnicastPkts": 146212,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 218296689,
                    "outUnicastPkts": 145395,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 853189966,
                    "inUnicastPkts": 569391,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 853001324,
                    "outUnicastPkts": 569204,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 937641354,
                    "inUnicastPkts": 625748,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 937520813,
                    "outUnicastPkts": 625758,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 156010914,
                    "inUnicastPkts": 103888,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 155929298,
                    "outUnicastPkts": 104650,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-SD_CH",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "Fujitsu",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-6633",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-SD_CH",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-sd_ch",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-20",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 38.2682,
                    "longitude": 140.8694,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 218035067,
                    "inUnicastPkts": 146212,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 218296689,
                    "outUnicastPkts": 145395,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 853189966,
                    "inUnicastPkts": 569391,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 853001324,
                    "outUnicastPkts": 569204,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 937641354,
                    "inUnicastPkts": 625748,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 937520813,
                    "outUnicastPkts": 625758,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 156010914,
                    "inUnicastPkts": 103888,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 155929298,
                    "outUnicastPkts": 104650,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-SD_CH",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-3123",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-NG_SM",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-ng_sm",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-35",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.1814,
                    "longitude": 136.9064,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 347178881,
                    "inUnicastPkts": 231715,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 347593301,
                    "outUnicastPkts": 232252,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 887560701,
                    "inUnicastPkts": 592041,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 887698574,
                    "outUnicastPkts": 591868,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 405880712,
                    "inUnicastPkts": 271016,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 406002221,
                    "outUnicastPkts": 270725,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 882306313,
                    "inUnicastPkts": 588104,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 882365045,
                    "outUnicastPkts": 588645,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-NG_SM",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "Rakuten Symphony",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-5910",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-NG_SM",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-ng_sm",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-35",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.1814,
                    "longitude": 136.9064,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 347178881,
                    "inUnicastPkts": 231715,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 347593301,
                    "outUnicastPkts": 232252,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 887560701,
                    "inUnicastPkts": 592041,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 887698574,
                    "outUnicastPkts": 591868,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 405880712,
                    "inUnicastPkts": 271016,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 406002221,
                    "outUnicastPkts": 270725,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 882306313,
                    "inUnicastPkts": 588104,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 882365045,
                    "outUnicastPkts": 588645,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-NG_SM",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-7062",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-FK_TJ",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-fk_tj",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-5",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 33.5902,
                    "longitude": 130.4017,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 500479351,
                    "inUnicastPkts": 333915,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 500508985,
                    "outUnicastPkts": 333936,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 660267647,
                    "inUnicastPkts": 440418,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 660390243,
                    "outUnicastPkts": 440453,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 792611597,
                    "inUnicastPkts": 528608,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 792464573,
                    "outUnicastPkts": 529123,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 951330695,
                    "inUnicastPkts": 634826,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 951471406,
                    "outUnicastPkts": 634570,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-FK_TJ",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "NEC Corporation",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-8951",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-FK_TJ",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-fk_tj",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-5",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 33.5902,
                    "longitude": 130.4017,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 500479351,
                    "inUnicastPkts": 333915,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 500508985,
                    "outUnicastPkts": 333936,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 660267647,
                    "inUnicastPkts": 440418,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 660390243,
                    "outUnicastPkts": 440453,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 792611597,
                    "inUnicastPkts": 528608,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 792464573,
                    "outUnicastPkts": 529123,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 951330695,
                    "inUnicastPkts": 634826,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 951471406,
                    "outUnicastPkts": 634570,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-FK_TJ",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-2144",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "CU-node-OK_NH",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "cu-node-ok_nh",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-49",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 26.2124,
                    "longitude": 127.6809,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 19214442,
                    "inUnicastPkts": 13050,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 18995247,
                    "outUnicastPkts": 13070,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 636937686,
                    "inUnicastPkts": 425140,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 637272841,
                    "outUnicastPkts": 425003,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 26838294,
                    "inUnicastPkts": 18129,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 26829468,
                    "outUnicastPkts": 18563,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 443264777,
                    "inUnicastPkts": 296244,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 443157956,
                    "outUnicastPkts": 295502,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "srv-CU-node-OK_NH",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "Fujitsu",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-3108",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "TerraBeam-node-OK_NH",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "NTN Ground Station",
        "ietfSystem": {
            "hostname": "terrabeam-node-ok_nh",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "bootDatetime": "2026-04-01T08:15:00.000Z", "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-49",
            "rackPosition": 22,
            "notes": ""
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 26.2124,
                    "longitude": 127.6809,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 19214442,
                    "inUnicastPkts": 13050,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 18995247,
                    "outUnicastPkts": 13070,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 636937686,
                    "inUnicastPkts": 425140,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 637272841,
                    "outUnicastPkts": 425003,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 26838294,
                    "inUnicastPkts": 18129,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 26829468,
                    "outUnicastPkts": 18563,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 443264777,
                    "inUnicastPkts": 296244,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 443157956,
                    "outUnicastPkts": 295502,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "tb-ch-TerraBeam-node-OK_NH",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-1758",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-TK1",
        "name": "TK1-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-24",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "NTT Otemachi Building",
        "ietfSystem": {
            "hostname": "opt-tk1-01",
            "contact": "opt-noc@telecom.jp",
            "location": "2-3-1 Otemachi, Chiyoda-ku, Tokyo 100-0004, Rack R9D",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.539Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.6881,
                    "longitude": 139.7635,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 108780132,
                    "inUnicastPkts": 72734,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 108630875,
                    "outUnicastPkts": 72430,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 672939088,
                    "inUnicastPkts": 448793,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 672990571,
                    "outUnicastPkts": 449003,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 11435430,
                    "inUnicastPkts": 8215,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 11539297,
                    "outUnicastPkts": 7955,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 9240894,
                    "inUnicastPkts": 6739,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 9046838,
                    "outUnicastPkts": 6025,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-TK1",
                "name": "TK1-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK503KA",
                "serialNumber": "CN-CH-TK1-001",
                "status": "active"
            },
            {
                "uuid": "mod-TK1-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-TK1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-TK1-W5E",
                "status": "active"
            },
            {
                "uuid": "port-TK1-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-TK1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TK1-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TK1-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TK1-1",
                "status": "active"
            },
            {
                "uuid": "port-TK1-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-TK1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TK1-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TK1-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TK1-2",
                "status": "active"
            },
            {
                "uuid": "port-TK1-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-TK1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TK1-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TK1-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TK1-3",
                "status": "active"
            },
            {
                "uuid": "port-TK1-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-TK1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TK1-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TK1-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TK1-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-TH_OTE",
        "name": "TH_OTE-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-28",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "KDDI Otemachi Building",
        "ietfSystem": {
            "hostname": "opt-th_ote-01",
            "contact": "opt-noc@telecom.jp",
            "location": "1-8-1 Otemachi, Chiyoda-ku, Tokyo 100-0004, Rack R10D",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.539Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.6885,
                    "longitude": 139.763,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 874270920,
                    "inUnicastPkts": 582606,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 874321715,
                    "outUnicastPkts": 583376,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 573430001,
                    "inUnicastPkts": 382806,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 573409492,
                    "outUnicastPkts": 382846,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 827474076,
                    "inUnicastPkts": 552550,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 827632024,
                    "outUnicastPkts": 552142,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 115463546,
                    "inUnicastPkts": 77344,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 115108747,
                    "outUnicastPkts": 77295,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-TH_OTE",
                "name": "TH_OTE-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK503KA",
                "serialNumber": "CN-CH-TH_OTE-001",
                "status": "active"
            },
            {
                "uuid": "mod-TH_OTE-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-TH_OTE",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-TH_OTE-W5E",
                "status": "active"
            },
            {
                "uuid": "port-TH_OTE-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-TH_OTE-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TH_OTE-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TH_OTE-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TH_OTE-1",
                "status": "active"
            },
            {
                "uuid": "port-TH_OTE-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-TH_OTE-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TH_OTE-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TH_OTE-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TH_OTE-2",
                "status": "active"
            },
            {
                "uuid": "port-TH_OTE-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-TH_OTE-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TH_OTE-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TH_OTE-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TH_OTE-3",
                "status": "active"
            },
            {
                "uuid": "port-TH_OTE-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-TH_OTE-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TH_OTE-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TH_OTE-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TH_OTE-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-TY1",
        "name": "TY1-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-49",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "Equinix TY1 (Heiwajima)",
        "ietfSystem": {
            "hostname": "opt-ty1-01",
            "contact": "opt-noc@telecom.jp",
            "location": "TRC-C B-Block, 6-5-1 Heiwajima, Ota-ku, Tokyo 143-0006, Rack R2F",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.539Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.5828,
                    "longitude": 139.7424,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 846864912,
                    "inUnicastPkts": 564870,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 846983421,
                    "outUnicastPkts": 565013,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 142042574,
                    "inUnicastPkts": 95170,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 142369311,
                    "outUnicastPkts": 94880,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 716073238,
                    "inUnicastPkts": 477691,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 716015037,
                    "outUnicastPkts": 478174,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 272367635,
                    "inUnicastPkts": 181754,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 272221153,
                    "outUnicastPkts": 181539,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-TY1",
                "name": "TY1-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "186-0601-900",
                "serialNumber": "CN-CH-TY1-001",
                "status": "active"
            },
            {
                "uuid": "mod-TY1-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-TY1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-TY1-W5E",
                "status": "active"
            },
            {
                "uuid": "port-TY1-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-TY1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TY1-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TY1-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TY1-1",
                "status": "active"
            },
            {
                "uuid": "port-TY1-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-TY1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TY1-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TY1-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TY1-2",
                "status": "active"
            },
            {
                "uuid": "port-TY1-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-TY1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TY1-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TY1-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TY1-3",
                "status": "active"
            },
            {
                "uuid": "port-TY1-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-TY1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TY1-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TY1-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TY1-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-CC1",
        "name": "CC1-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-6",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "AT TOKYO Chuo Center",
        "ietfSystem": {
            "hostname": "opt-cc1-01",
            "contact": "opt-noc@telecom.jp",
            "location": "6-2-12 Toyosu, Koto-ku, Tokyo 135-0061, Rack R3B",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.539Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.6531,
                    "longitude": 139.7963,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 786931529,
                    "inUnicastPkts": 525207,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 787129019,
                    "outUnicastPkts": 525255,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 95725735,
                    "inUnicastPkts": 64248,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 96050609,
                    "outUnicastPkts": 63961,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 459117737,
                    "inUnicastPkts": 306949,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 459327461,
                    "outUnicastPkts": 306833,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 244577470,
                    "inUnicastPkts": 163547,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 244752302,
                    "outUnicastPkts": 163792,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-CC1",
                "name": "CC1-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "186-0601-900",
                "serialNumber": "CN-CH-CC1-001",
                "status": "active"
            },
            {
                "uuid": "mod-CC1-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-CC1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-CC1-W5E",
                "status": "active"
            },
            {
                "uuid": "port-CC1-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-CC1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-CC1-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-CC1-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-CC1-1",
                "status": "active"
            },
            {
                "uuid": "port-CC1-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-CC1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-CC1-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-CC1-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-CC1-2",
                "status": "active"
            },
            {
                "uuid": "port-CC1-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-CC1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-CC1-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-CC1-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-CC1-3",
                "status": "active"
            },
            {
                "uuid": "port-CC1-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-CC1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-CC1-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-CC1-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-CC1-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-FUJI_SUMMIT",
        "name": "Fuji-Summit-NTN-Base",
        "facilityLocation": {
            "siteName": "Mt. Fuji Summit Observatory",
            "buildingOrHut": "Telecom Hut Alpha",
            "rackIdentifier": "Rack-1",
            "rackPosition": 22,
            "notes": "Telco hut co-locates 3 additional empty/third-party racks."
        },
        "type": "gNB_NTN",
        "layer": "RAN",
        "location": "Mount Fuji Summit",
        "ietfSystem": {
            "hostname": "gnb-fuji-01",
            "contact": "ntn-noc@telecom.jp",
            "location": "Summit Observatory, Shizuoka Prefecture, Japan",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.539Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.3606,
                    "longitude": 138.7274,
                    "height": 3776
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 481819442,
                    "inUnicastPkts": 321110,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 481826408,
                    "outUnicastPkts": 321076,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 305584116,
                    "inUnicastPkts": 203888,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 305582219,
                    "outUnicastPkts": 204359,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 706733691,
                    "inUnicastPkts": 471511,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 706563500,
                    "outUnicastPkts": 471203,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 953461777,
                    "inUnicastPkts": 636090,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 953303764,
                    "outUnicastPkts": 635511,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-SHN_CO",
                "name": "SHN_CO-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "186-0601-900",
                "serialNumber": "CN-CH-SHN_CO-001",
                "status": "active"
            },
            {
                "uuid": "mod-SHN_CO-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-SHN_CO",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-SHN_CO-W5E",
                "status": "active"
            },
            {
                "uuid": "port-SHN_CO-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-SHN_CO-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-SHN_CO-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-SHN_CO-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-SHN_CO-1",
                "status": "active"
            },
            {
                "uuid": "port-SHN_CO-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-SHN_CO-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-SHN_CO-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-SHN_CO-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-SHN_CO-2",
                "status": "active"
            },
            {
                "uuid": "port-SHN_CO-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-SHN_CO-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-SHN_CO-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-SHN_CO-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-SHN_CO-3",
                "status": "active"
            },
            {
                "uuid": "port-SHN_CO-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-SHN_CO-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-SHN_CO-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-SHN_CO-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-SHN_CO-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-TYO2",
        "name": "TYO2-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-12",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "ComSpace I",
        "ietfSystem": {
            "hostname": "opt-tyo2-01",
            "contact": "opt-noc@telecom.jp",
            "location": "1-8-30 Higashi-Nihonbashi, Chuo-ku, Tokyo 103-0004, Rack R9F",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.539Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 36.2333,
                    "longitude": 137.65,
                    "height": 2500
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 584278247,
                    "inUnicastPkts": 389753,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 584329599,
                    "outUnicastPkts": 389923,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 436000390,
                    "inUnicastPkts": 291369,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 436108227,
                    "outUnicastPkts": 291563,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 484826595,
                    "inUnicastPkts": 323330,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 484863964,
                    "outUnicastPkts": 323077,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 555405474,
                    "inUnicastPkts": 370365,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 555646535,
                    "outUnicastPkts": 370464,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-TYO2",
                "name": "TYO2-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "186-0601-900",
                "serialNumber": "CN-CH-TYO2-001",
                "status": "active"
            },
            {
                "uuid": "mod-TYO2-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-TYO2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-TYO2-W5E",
                "status": "active"
            },
            {
                "uuid": "port-TYO2-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-TYO2-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TYO2-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TYO2-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TYO2-1",
                "status": "active"
            },
            {
                "uuid": "port-TYO2-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-TYO2-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TYO2-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TYO2-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TYO2-2",
                "status": "active"
            },
            {
                "uuid": "port-TYO2-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-TYO2-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TYO2-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TYO2-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TYO2-3",
                "status": "active"
            },
            {
                "uuid": "port-TYO2-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-TYO2-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-TYO2-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-TYO2-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-TYO2-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-M_CLS",
        "name": "M_CLS-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-25",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "Maruyama CLS",
        "ietfSystem": {
            "hostname": "opt-m_cls-01",
            "contact": "opt-noc@telecom.jp",
            "location": "2698-19 Shirako, Minamiboso-shi, Chiba 299-2521, Rack R1E",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.539Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.0392,
                    "longitude": 139.9928,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 201430344,
                    "inUnicastPkts": 134862,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 201481926,
                    "outUnicastPkts": 134725,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 783029569,
                    "inUnicastPkts": 521954,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 782911387,
                    "outUnicastPkts": 521737,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 234349581,
                    "inUnicastPkts": 156922,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 234525212,
                    "outUnicastPkts": 157059,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 801942985,
                    "inUnicastPkts": 534871,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 801833375,
                    "outUnicastPkts": 535134,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-M_CLS",
                "name": "M_CLS-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "186-0601-900",
                "serialNumber": "CN-CH-M_CLS-001",
                "status": "active"
            },
            {
                "uuid": "mod-M_CLS-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-M_CLS",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-M_CLS-W5E",
                "status": "active"
            },
            {
                "uuid": "port-M_CLS-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-M_CLS-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-M_CLS-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-M_CLS-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-M_CLS-1",
                "status": "active"
            },
            {
                "uuid": "port-M_CLS-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-M_CLS-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-M_CLS-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-M_CLS-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-M_CLS-2",
                "status": "active"
            },
            {
                "uuid": "port-M_CLS-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-M_CLS-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-M_CLS-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-M_CLS-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-M_CLS-3",
                "status": "active"
            },
            {
                "uuid": "port-M_CLS-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-M_CLS-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-M_CLS-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-M_CLS-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-M_CLS-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-OS1",
        "name": "OS1-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-9",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "NTT Telepark Dojima No. 1",
        "ietfSystem": {
            "hostname": "opt-os1-01",
            "contact": "opt-noc@telecom.jp",
            "location": "3-1-59 Dojima, Kita-ku, Osaka-shi, Osaka 530-0003, Rack R10C",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.539Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.6961,
                    "longitude": 135.495,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 432380504,
                    "inUnicastPkts": 288715,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 432611305,
                    "outUnicastPkts": 288414,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 631319636,
                    "inUnicastPkts": 421556,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 631305326,
                    "outUnicastPkts": 420949,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 35572355,
                    "inUnicastPkts": 24434,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 35544589,
                    "outUnicastPkts": 23922,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 927629633,
                    "inUnicastPkts": 618515,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 928015306,
                    "outUnicastPkts": 619317,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-OS1",
                "name": "OS1-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK503KA",
                "serialNumber": "CN-CH-OS1-001",
                "status": "active"
            },
            {
                "uuid": "mod-OS1-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-OS1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-OS1-W5E",
                "status": "active"
            },
            {
                "uuid": "port-OS1-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-OS1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-OS1-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-OS1-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-OS1-1",
                "status": "active"
            },
            {
                "uuid": "port-OS1-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-OS1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-OS1-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-OS1-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-OS1-2",
                "status": "active"
            },
            {
                "uuid": "port-OS1-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-OS1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-OS1-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-OS1-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-OS1-3",
                "status": "active"
            },
            {
                "uuid": "port-OS1-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-OS1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-OS1-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-OS1-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-OS1-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-OS3",
        "name": "OS3-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-37",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "NTT Telepark Dojima No. 3",
        "ietfSystem": {
            "hostname": "opt-os3-01",
            "contact": "opt-noc@telecom.jp",
            "location": "3-1-59 Dojima, Kita-ku, Osaka-shi, Osaka 530-0003, Rack R8B",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.539Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.6963,
                    "longitude": 135.4952,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 447354386,
                    "inUnicastPkts": 298472,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 447500022,
                    "outUnicastPkts": 298347,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 785778435,
                    "inUnicastPkts": 524112,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 785878472,
                    "outUnicastPkts": 524188,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 907173512,
                    "inUnicastPkts": 605270,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 907088402,
                    "outUnicastPkts": 605470,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 698444467,
                    "inUnicastPkts": 466166,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 698049457,
                    "outUnicastPkts": 466080,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-OS3",
                "name": "OS3-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK503KA",
                "serialNumber": "CN-CH-OS3-001",
                "status": "active"
            },
            {
                "uuid": "mod-OS3-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-OS3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-OS3-W5E",
                "status": "active"
            },
            {
                "uuid": "port-OS3-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-OS3-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-OS3-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-OS3-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-OS3-1",
                "status": "active"
            },
            {
                "uuid": "port-OS3-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-OS3-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-OS3-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-OS3-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-OS3-2",
                "status": "active"
            },
            {
                "uuid": "port-OS3-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-OS3-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-OS3-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-OS3-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-OS3-3",
                "status": "active"
            },
            {
                "uuid": "port-OS3-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-OS3-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-OS3-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-OS3-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-OS3-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-DC12",
        "name": "DC12-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-25",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "NTT DATA Dojima Building",
        "ietfSystem": {
            "hostname": "opt-dc12-01",
            "contact": "opt-noc@telecom.jp",
            "location": "3-1-21 Dojima, Kita-ku, Osaka-shi, Osaka 530-0003, Rack R9F",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.539Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.696,
                    "longitude": 135.4955,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 828281857,
                    "inUnicastPkts": 552116,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 828384542,
                    "outUnicastPkts": 552449,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 217281741,
                    "inUnicastPkts": 144831,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 217222727,
                    "outUnicastPkts": 145108,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 705293526,
                    "inUnicastPkts": 470552,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 705333437,
                    "outUnicastPkts": 470665,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 534204949,
                    "inUnicastPkts": 356740,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 534496542,
                    "outUnicastPkts": 356348,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-DC12",
                "name": "DC12-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "186-0601-900",
                "serialNumber": "CN-CH-DC12-001",
                "status": "active"
            },
            {
                "uuid": "mod-DC12-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-DC12",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-DC12-W5E",
                "status": "active"
            },
            {
                "uuid": "port-DC12-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-DC12-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-DC12-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-DC12-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-DC12-1",
                "status": "active"
            },
            {
                "uuid": "port-DC12-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-DC12-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-DC12-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-DC12-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-DC12-2",
                "status": "active"
            },
            {
                "uuid": "port-DC12-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-DC12-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-DC12-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-DC12-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-DC12-3",
                "status": "active"
            },
            {
                "uuid": "port-DC12-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-DC12-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-DC12-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-DC12-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-DC12-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-EQ_OS1",
        "name": "EQ_OS1-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-19",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "Equinix OS1",
        "ietfSystem": {
            "hostname": "opt-eq_os1-01",
            "contact": "opt-noc@telecom.jp",
            "location": "1-26-1 Shinmachi, Nishi-ku, Osaka-shi, Osaka 550-0013, Rack R5F",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.539Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.6763,
                    "longitude": 135.4947,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 243704328,
                    "inUnicastPkts": 163176,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 244032027,
                    "outUnicastPkts": 162835,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 612780665,
                    "inUnicastPkts": 408801,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 612883052,
                    "outUnicastPkts": 408652,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 433366743,
                    "inUnicastPkts": 289606,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 433357363,
                    "outUnicastPkts": 289459,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 505544619,
                    "inUnicastPkts": 337195,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 505856082,
                    "outUnicastPkts": 337351,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-EQ_OS1",
                "name": "EQ_OS1-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "186-0601-900",
                "serialNumber": "CN-CH-EQ_OS1-001",
                "status": "active"
            },
            {
                "uuid": "mod-EQ_OS1-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-EQ_OS1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-EQ_OS1-W5E",
                "status": "active"
            },
            {
                "uuid": "port-EQ_OS1-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-EQ_OS1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-EQ_OS1-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-EQ_OS1-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-EQ_OS1-1",
                "status": "active"
            },
            {
                "uuid": "port-EQ_OS1-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-EQ_OS1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-EQ_OS1-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-EQ_OS1-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-EQ_OS1-2",
                "status": "active"
            },
            {
                "uuid": "port-EQ_OS1-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-EQ_OS1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-EQ_OS1-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-EQ_OS1-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-EQ_OS1-3",
                "status": "active"
            },
            {
                "uuid": "port-EQ_OS1-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-EQ_OS1-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-EQ_OS1-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-EQ_OS1-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-EQ_OS1-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-KOZU",
        "name": "KOZU-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-4",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "NTT West Osaka (Kozu)",
        "ietfSystem": {
            "hostname": "opt-kozu-01",
            "contact": "opt-noc@telecom.jp",
            "location": "3-3-30 Kawarayamachi, Chuo-ku, Osaka-shi, Osaka 542-0066, Rack R3C",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.540Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 34.6677,
                    "longitude": 135.5113,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 408923308,
                    "inUnicastPkts": 272691,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 408659238,
                    "outUnicastPkts": 272667,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 660544307,
                    "inUnicastPkts": 440676,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 660452098,
                    "outUnicastPkts": 440310,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 623494047,
                    "inUnicastPkts": 415793,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 623366305,
                    "outUnicastPkts": 416546,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 685845210,
                    "inUnicastPkts": 458014,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 685800749,
                    "outUnicastPkts": 457537,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-KOZU",
                "name": "KOZU-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "186-0601-900",
                "serialNumber": "CN-CH-KOZU-001",
                "status": "active"
            },
            {
                "uuid": "mod-KOZU-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-KOZU",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-KOZU-W5E",
                "status": "active"
            },
            {
                "uuid": "port-KOZU-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-KOZU-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-KOZU-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-KOZU-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-KOZU-1",
                "status": "active"
            },
            {
                "uuid": "port-KOZU-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-KOZU-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-KOZU-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-KOZU-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-KOZU-2",
                "status": "active"
            },
            {
                "uuid": "port-KOZU-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-KOZU-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-KOZU-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-KOZU-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-KOZU-3",
                "status": "active"
            },
            {
                "uuid": "port-KOZU-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-KOZU-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-KOZU-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-KOZU-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-KOZU-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-SP_OD",
        "name": "SP_OD-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-33",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "NTT DOCOMO Sapporo",
        "ietfSystem": {
            "hostname": "opt-sp_od-01",
            "contact": "opt-noc@telecom.jp",
            "location": "7-3 Odori Nishi, Chuo-ku, Sapporo-shi, Hokkaido 060-0042, Rack R2B",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.540Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 43.0618,
                    "longitude": 141.3545,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 26444450,
                    "inUnicastPkts": 18476,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 26283626,
                    "outUnicastPkts": 18340,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 616525461,
                    "inUnicastPkts": 411681,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 616224227,
                    "outUnicastPkts": 411133,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 170049552,
                    "inUnicastPkts": 113701,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 170118002,
                    "outUnicastPkts": 113950,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 301108843,
                    "inUnicastPkts": 201325,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 301485949,
                    "outUnicastPkts": 200678,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-SP_OD",
                "name": "SP_OD-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "186-0601-900",
                "serialNumber": "CN-CH-SP_OD-001",
                "status": "active"
            },
            {
                "uuid": "mod-SP_OD-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-SP_OD",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-SP_OD-W5E",
                "status": "active"
            },
            {
                "uuid": "port-SP_OD-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-SP_OD-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-SP_OD-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-SP_OD-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-SP_OD-1",
                "status": "active"
            },
            {
                "uuid": "port-SP_OD-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-SP_OD-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-SP_OD-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-SP_OD-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-SP_OD-2",
                "status": "active"
            },
            {
                "uuid": "port-SP_OD-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-SP_OD-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-SP_OD-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-SP_OD-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-SP_OD-3",
                "status": "active"
            },
            {
                "uuid": "port-SP_OD-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-SP_OD-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-SP_OD-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-SP_OD-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-SP_OD-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-SD_CH",
        "name": "SD_CH-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-5",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "NTT East Sendai",
        "ietfSystem": {
            "hostname": "opt-sd_ch-01",
            "contact": "opt-noc@telecom.jp",
            "location": "4-4-19 Chuo, Aoba-ku, Sendai-shi, Miyagi 980-0021, Rack R6E",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.540Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 38.2682,
                    "longitude": 140.8694,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 218035067,
                    "inUnicastPkts": 146212,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 218296689,
                    "outUnicastPkts": 145395,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 853189966,
                    "inUnicastPkts": 569391,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 853001324,
                    "outUnicastPkts": 569204,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 937641354,
                    "inUnicastPkts": 625748,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 937520813,
                    "outUnicastPkts": 625758,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 156010914,
                    "inUnicastPkts": 103888,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 155929298,
                    "outUnicastPkts": 104650,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-SD_CH",
                "name": "SD_CH-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "186-0601-900",
                "serialNumber": "CN-CH-SD_CH-001",
                "status": "active"
            },
            {
                "uuid": "mod-SD_CH-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-SD_CH",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-SD_CH-W5E",
                "status": "active"
            },
            {
                "uuid": "port-SD_CH-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-SD_CH-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-SD_CH-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-SD_CH-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-SD_CH-1",
                "status": "active"
            },
            {
                "uuid": "port-SD_CH-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-SD_CH-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-SD_CH-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-SD_CH-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-SD_CH-2",
                "status": "active"
            },
            {
                "uuid": "port-SD_CH-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-SD_CH-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-SD_CH-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-SD_CH-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-SD_CH-3",
                "status": "active"
            },
            {
                "uuid": "port-SD_CH-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-SD_CH-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-SD_CH-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-SD_CH-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-SD_CH-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-NG_SM",
        "name": "NG_SM-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-43",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "NTT DOCOMO Nagoya",
        "ietfSystem": {
            "hostname": "opt-ng_sm-01",
            "contact": "opt-noc@telecom.jp",
            "location": "1-9-1 Sannomaru, Naka-ku, Nagoya-shi, Aichi 460-0001, Rack R7B",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.540Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 35.1814,
                    "longitude": 136.9064,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 347178881,
                    "inUnicastPkts": 231715,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 347593301,
                    "outUnicastPkts": 232252,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 887560701,
                    "inUnicastPkts": 592041,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 887698574,
                    "outUnicastPkts": 591868,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 405880712,
                    "inUnicastPkts": 271016,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 406002221,
                    "outUnicastPkts": 270725,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 882306313,
                    "inUnicastPkts": 588104,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 882365045,
                    "outUnicastPkts": 588645,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-NG_SM",
                "name": "NG_SM-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "186-0601-900",
                "serialNumber": "CN-CH-NG_SM-001",
                "status": "active"
            },
            {
                "uuid": "mod-NG_SM-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-NG_SM",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-NG_SM-W5E",
                "status": "active"
            },
            {
                "uuid": "port-NG_SM-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-NG_SM-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-NG_SM-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-NG_SM-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-NG_SM-1",
                "status": "active"
            },
            {
                "uuid": "port-NG_SM-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-NG_SM-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-NG_SM-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-NG_SM-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-NG_SM-2",
                "status": "active"
            },
            {
                "uuid": "port-NG_SM-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-NG_SM-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-NG_SM-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-NG_SM-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-NG_SM-3",
                "status": "active"
            },
            {
                "uuid": "port-NG_SM-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-NG_SM-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-NG_SM-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-NG_SM-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-NG_SM-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-FK_TJ",
        "name": "FK_TJ-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-38",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "NTT Fukuoka",
        "ietfSystem": {
            "hostname": "opt-fk_tj-01",
            "contact": "opt-noc@telecom.jp",
            "location": "2-4-38 Tenjin, Chuo-ku, Fukuoka-shi, Fukuoka 810-0001, Rack R4B",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.540Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 33.5902,
                    "longitude": 130.4017,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 500479351,
                    "inUnicastPkts": 333915,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 500508985,
                    "outUnicastPkts": 333936,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 660267647,
                    "inUnicastPkts": 440418,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 660390243,
                    "outUnicastPkts": 440453,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 792611597,
                    "inUnicastPkts": 528608,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 792464573,
                    "outUnicastPkts": 529123,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 951330695,
                    "inUnicastPkts": 634826,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 951471406,
                    "outUnicastPkts": 634570,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-FK_TJ",
                "name": "FK_TJ-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "186-0601-900",
                "serialNumber": "CN-CH-FK_TJ-001",
                "status": "active"
            },
            {
                "uuid": "mod-FK_TJ-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-FK_TJ",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-FK_TJ-W5E",
                "status": "active"
            },
            {
                "uuid": "port-FK_TJ-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-FK_TJ-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-FK_TJ-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-FK_TJ-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-FK_TJ-1",
                "status": "active"
            },
            {
                "uuid": "port-FK_TJ-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-FK_TJ-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-FK_TJ-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-FK_TJ-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-FK_TJ-2",
                "status": "active"
            },
            {
                "uuid": "port-FK_TJ-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-FK_TJ-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-FK_TJ-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-FK_TJ-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-FK_TJ-3",
                "status": "active"
            },
            {
                "uuid": "port-FK_TJ-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-FK_TJ-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-FK_TJ-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-FK_TJ-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-FK_TJ-4",
                "status": "active"
            }
        ],
        "services": []
    },
    {
        "uuid": "node-OK_NH",
        "name": "OK_NH-OPT-Core",
        "facilityLocation": {
            "siteName": "NTN Ground Station Site",
            "buildingOrHut": "Telco Hut",
            "rackIdentifier": "Rack-29",
            "rackPosition": 22,
            "notes": ""
        },
        "type": "OPTICAL_SWITCH",
        "layer": "L0 (Optical)",
        "location": "NTT West Naha",
        "ietfSystem": {
            "hostname": "opt-ok_nh-01",
            "contact": "opt-noc@telecom.jp",
            "location": "1-1-15 Higashimachi, Naha-shi, Okinawa 900-0034, Rack R1F",
            "platform": {
                "osName": "SAOS",
                "osRelease": "10.7.1",
                "osVersion": "10.7",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "Asia/Tokyo",
                "currentDatetime": "2026-05-02T02:35:36.540Z"
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": {
                    "coordAccuracy": 1
                }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 26.2124,
                    "longitude": 127.6809,
                    "height": 10
                }
            }
        },
        "ietfInterfaces": [
            {
                "name": "opt-1/1",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 19214442,
                    "inUnicastPkts": 13050,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 18995247,
                    "outUnicastPkts": 13070,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/2",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 636937686,
                    "inUnicastPkts": 425140,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 637272841,
                    "outUnicastPkts": 425003,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/3",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 26838294,
                    "inUnicastPkts": 18129,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 26829468,
                    "outUnicastPkts": 18563,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "opt-1/4",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 800000000000,
                "description": "800G WaveLogic 5e Coherent Line",
                "statistics": {
                    "inOctets": 443264777,
                    "inUnicastPkts": 296244,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 443157956,
                    "outUnicastPkts": 295502,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            }
        ],
        "hardware": [
            {
                "uuid": "ch-OK_NH",
                "name": "OK_NH-Chassis",
                "class": "chassis",
                "manufacturer": "Ciena Corporation",
                "partNumber": "186-0601-900",
                "serialNumber": "CN-CH-OK_NH-001",
                "status": "active"
            },
            {
                "uuid": "mod-OK_NH-1",
                "name": "WaveLogic-5-Extreme",
                "class": "module",
                "parentUuid": "ch-OK_NH",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK540EC",
                "serialNumber": "CN-MOD-OK_NH-W5E",
                "status": "active"
            },
            {
                "uuid": "port-OK_NH-1",
                "name": "Line-Port-1",
                "class": "port",
                "parentUuid": "mod-OK_NH-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-OK_NH-1",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-OK_NH-1",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-OK_NH-1",
                "status": "active"
            },
            {
                "uuid": "port-OK_NH-2",
                "name": "Line-Port-2",
                "class": "port",
                "parentUuid": "mod-OK_NH-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-OK_NH-2",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-OK_NH-2",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-OK_NH-2",
                "status": "active"
            },
            {
                "uuid": "port-OK_NH-3",
                "name": "Line-Port-3",
                "class": "port",
                "parentUuid": "mod-OK_NH-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-OK_NH-3",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-OK_NH-3",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-OK_NH-3",
                "status": "active"
            },
            {
                "uuid": "port-OK_NH-4",
                "name": "Line-Port-4",
                "class": "port",
                "parentUuid": "mod-OK_NH-1",
                "status": "active"
            },
            {
                "uuid": "tcvr-OK_NH-4",
                "name": "800G-ZR-Optic",
                "class": "transceiver",
                "parentUuid": "port-OK_NH-4",
                "manufacturer": "Ciena Corporation",
                "partNumber": "NTK-800G-ZR",
                "serialNumber": "CN-TCV-OK_NH-4",
                "status": "active"
            }
        ],
        "services": []
    }
,
    {
        "uuid": "node-SAT1",
        "name": "LEO-SAT-1",
        "type": "SATELLITE",
        "layer": "LEO",
        "location": "LEO Orbit 1",
        "ietfSystem": {
            "hostname": "sat-1",
            "contact": "space-ops@telecom.jp",
            "location": "LEO 1200km",
            "platform": {
                "osName": "SpaceOS",
                "osRelease": "1.0",
                "osVersion": "1",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "UTC",
                "currentDatetime": new Date().toISOString()
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": { "coordAccuracy": 1 }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 28,
                    "longitude": 129,
                    "height": 1200000
                }
            }
        },
        "hardware": [
            {
                "uuid": "sat1-bus",
                "name": "JAC-Bus300-Telemetry-Chassis",
                "class": "chassis",
                "manufacturer": "Japan Aerospace Communications",
                "partNumber": "JAC-BUS-300-X1",
                "serialNumber": "JAC-LEO-1001",
                "status": "active",
                "description": "Standard LEO bus chassis providing power distribution, solar propulsion control, orbit status, thermal monitoring, and attitude control.",
                "alias": "SAT1 Telemetry Bus",
                "hardwareRev": "v3.2",
                "mfgDate": "2025-03-12T00:00:00Z"
            },
            {
                "uuid": "sat1-odu",
                "name": "O-DU Payload Processor Unit",
                "class": "module",
                "parentUuid": "sat1-bus",
                "manufacturer": "NEC Space Solutions",
                "partNumber": "ORAN-SAT-DU-Versal-S1",
                "serialNumber": "NEC-DU-LEO-SAT1-09",
                "status": "active",
                "description": "Regenerative space-grade Distributed Unit card with AMD/Xilinx Versal adaptive SoC. Processes MAC, RLC, and High-PHY 5G NTN layers under extreme radiation conditions.",
                "alias": "O-RAN DU Payload Baseband Card",
                "hardwareRev": "Rev C",
                "mfgDate": "2025-05-24T00:00:00Z",
                "softwareRev": [
                    { "name": "Open-DU-SpaceKernel", "revision": "v4.1.2" }
                ]
            },
            {
                "uuid": "sat1-oru",
                "name": "O-RU Digital Front End (DFE) payload",
                "class": "module",
                "parentUuid": "sat1-bus",
                "manufacturer": "Fujitsu Space Electronics",
                "partNumber": "ORAN-SAT-RU-DFE-1200",
                "serialNumber": "FUJ-RU-LEO-SAT1-44",
                "status": "active",
                "description": "Space-grade Radio Unit frontend supporting Open Front-haul Option-7.2x, dynamic digital up/downconversion, and packet synchronization.",
                "alias": "O-RAN RU DFE Front-End Card",
                "hardwareRev": "Rev B",
                "mfgDate": "2025-05-28T00:00:00Z"
            },
            {
                "uuid": "sat1-aesa",
                "name": "Ku/Ka Band Active Phased Array (AESA)",
                "class": "module",
                "parentUuid": "sat1-bus",
                "manufacturer": "Mitsubishi Heavy Space",
                "partNumber": "MHS-AESA-KU-KA-LEO",
                "serialNumber": "MHS-AESA-SAT1-02",
                "status": "active",
                "description": "Active Electronically Scanned Array implementing high-gain dynamic beamforming for 5G-NR user/feeder links.",
                "alias": "AESA steerable multi-beam payload",
                "hardwareRev": "v1.4",
                "mfgDate": "2025-06-02T00:00:00Z"
            },
            {
                "uuid": "sat1-gnss-clk",
                "name": "Locked GNSS Space Disciplined Clock",
                "class": "module",
                "parentUuid": "sat1-bus",
                "manufacturer": "Epson Space Technology",
                "partNumber": "EST-GNSS-CLK-10V",
                "serialNumber": "EPS-CLK-SAT1-105",
                "status": "active",
                "description": "Radiation-hardened GNSS-locked reference oscillator. Provides ultra-stable sub-nanosecond synchronization, satisfying O-RAN ITU-T G.8275.1 standards to compensate for high Doppler shift.",
                "alias": "IEEE 1588v2 Space Reference Clock",
                "hardwareRev": "v2.1",
                "mfgDate": "2025-04-10T00:00:00Z"
            },
            {
                "uuid": "sat1-laser-isl",
                "name": "Laser Terminal Inter-Satellite Link (ISL)",
                "class": "transceiver",
                "parentUuid": "sat1-bus",
                "manufacturer": "Toshiba Space Lab",
                "partNumber": "TOSH-ISL-OPT-100G",
                "serialNumber": "TOSH-ISL-SAT1-88",
                "status": "active",
                "description": "100 Gbps coherent Laser Communication Terminal (LCT) for intra-orbit satellite-to-satellite backhaul. Controlled by fine-pointing mechanism.",
                "alias": "Satellite Optical ISL Card",
                "hardwareRev": "v4.0",
                "mfgDate": "2025-07-01T00:00:00Z"
            }
        ],
        "ietfInterfaces": [
            {
                "name": "sat-1/f1-u",
                "description": "F1-User plane interface mapping active O-DU backhaul to ground gateway via NTN link",
                "type": "iana-if-type:ethernetCsmacd",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 10000000000,
                "physAddress": "aa:bb:cc:11:sat1",
                "statistics": {
                    "inOctets": 4510294101,
                    "inUnicastPkts": 3120194,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 9102485122,
                    "outUnicastPkts": 6481029,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "sat-1/open-front-haul",
                "description": "eCPRI front-haul connecting on-board O-DU component to O-RU component on payload bus",
                "type": "iana-if-type:ethernetCsmacd",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 25000000000,
                "physAddress": "aa:bb:cc:22:sat1",
                "statistics": {
                    "inOctets": 98124019201,
                    "inUnicastPkts": 81029104,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 98132910293,
                    "outUnicastPkts": 81031024,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "sat-1/isl-port",
                "description": "High-speed laser cross-link inter-satellite optical interface (100G Coherent Laser)",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 100000000000,
                "physAddress": "aa:bb:cc:33:sat1",
                "statistics": {
                    "inOctets": 128941029482,
                    "inUnicastPkts": 951029141,
                    "inErrors": 2,
                    "inDiscards": 0,
                    "outOctets": 141094851029,
                    "outUnicastPkts": 102941019,
                    "outErrors": 1,
                    "outDiscards": 0
                }
            }
        ],
        "services": []
    },
    {
        "uuid": "node-SAT2",
        "name": "LEO-SAT-2",
        "type": "SATELLITE",
        "layer": "LEO",
        "location": "LEO Orbit 2",
        "ietfSystem": {
            "hostname": "sat-2",
            "contact": "space-ops@telecom.jp",
            "location": "LEO 1200km",
            "platform": {
                "osName": "SpaceOS",
                "osRelease": "1.0",
                "osVersion": "1",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "UTC",
                "currentDatetime": new Date().toISOString()
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": { "coordAccuracy": 1 }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 33,
                    "longitude": 133,
                    "height": 1200000
                }
            }
        },
        "hardware": [
            {
                "uuid": "sat2-bus",
                "name": "JAC-Bus300-Telemetry-Chassis",
                "class": "chassis",
                "manufacturer": "Japan Aerospace Communications",
                "partNumber": "JAC-BUS-300-X1",
                "serialNumber": "JAC-LEO-1002",
                "status": "active",
                "description": "Standard LEO bus chassis providing power distribution, solar propulsion control, orbit status, thermal monitoring, and attitude control.",
                "alias": "SAT2 Telemetry Bus",
                "hardwareRev": "v3.2",
                "mfgDate": "2025-03-24T00:00:00Z"
            },
            {
                "uuid": "sat2-odu",
                "name": "O-DU Payload Processor Unit",
                "class": "module",
                "parentUuid": "sat2-bus",
                "manufacturer": "NEC Space Solutions",
                "partNumber": "ORAN-SAT-DU-Versal-S2",
                "serialNumber": "NEC-DU-LEO-SAT2-10",
                "status": "active",
                "description": "Regenerative space-grade Distributed Unit card with AMD/Xilinx Versal adaptive SoC. Processes MAC, RLC, and High-PHY 5G NTN layers under extreme radiation conditions.",
                "alias": "O-RAN DU Payload Baseband Card",
                "hardwareRev": "Rev C",
                "mfgDate": "2025-05-24T00:00:00Z",
                "softwareRev": [
                    { "name": "Open-DU-SpaceKernel", "revision": "v4.1.2" }
                ]
            },
            {
                "uuid": "sat2-oru",
                "name": "O-RU Digital Front End (DFE) payload",
                "class": "module",
                "parentUuid": "sat2-bus",
                "manufacturer": "Fujitsu Space Electronics",
                "partNumber": "ORAN-SAT-RU-DFE-1200",
                "serialNumber": "FUJ-RU-LEO-SAT2-45",
                "status": "active",
                "description": "Space-grade Radio Unit frontend supporting Open Front-haul Option-7.2x, dynamic digital up/downconversion, and packet synchronization.",
                "alias": "O-RAN RU DFE Front-End Card",
                "hardwareRev": "Rev B",
                "mfgDate": "2025-05-28T00:00:00Z"
            },
            {
                "uuid": "sat2-aesa",
                "name": "Ku/Ka Band Active Phased Array (AESA)",
                "class": "module",
                "parentUuid": "sat2-bus",
                "manufacturer": "Mitsubishi Heavy Space",
                "partNumber": "MHS-AESA-KU-KA-LEO",
                "serialNumber": "MHS-AESA-SAT2-03",
                "status": "active",
                "description": "Active Electronically Scanned Array implementing high-gain dynamic beamforming for 5G-NR user/feeder links.",
                "alias": "AESA steerable multi-beam payload",
                "hardwareRev": "v1.4",
                "mfgDate": "2025-06-03T00:00:00Z"
            },
            {
                "uuid": "sat2-gnss-clk",
                "name": "Locked GNSS Space Disciplined Clock",
                "class": "module",
                "parentUuid": "sat2-bus",
                "manufacturer": "Epson Space Technology",
                "partNumber": "EST-GNSS-CLK-10V",
                "serialNumber": "EPS-CLK-SAT2-106",
                "status": "active",
                "description": "Radiation-hardened GNSS-locked reference oscillator. Provides ultra-stable sub-nanosecond synchronization, satisfying O-RAN ITU-T G.8275.1 standards to compensate for high Doppler shift.",
                "alias": "IEEE 1588v2 Space Reference Clock",
                "hardwareRev": "v2.1",
                "mfgDate": "2025-04-12T00:00:00Z"
            },
            {
                "uuid": "sat2-laser-isl",
                "name": "Laser Terminal Inter-Satellite Link (ISL)",
                "class": "transceiver",
                "parentUuid": "sat2-bus",
                "manufacturer": "Toshiba Space Lab",
                "partNumber": "TOSH-ISL-OPT-100G",
                "serialNumber": "TOSH-ISL-SAT2-89",
                "status": "active",
                "description": "100 Gbps coherent Laser Communication Terminal (LCT) for intra-orbit satellite-to-satellite backhaul. Controlled by fine-pointing mechanism.",
                "alias": "Satellite Optical ISL Card",
                "hardwareRev": "v4.0",
                "mfgDate": "2025-07-02T00:00:00Z"
            }
        ],
        "ietfInterfaces": [
            {
                "name": "sat-2/f1-u",
                "description": "F1-User plane interface mapping active O-DU backhaul to ground gateway via NTN link",
                "type": "iana-if-type:ethernetCsmacd",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 10000000000,
                "physAddress": "aa:bb:cc:11:sat2",
                "statistics": {
                    "inOctets": 4291049281,
                    "inUnicastPkts": 2981023,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 8941029410,
                    "outUnicastPkts": 6128410,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "sat-2/open-front-haul",
                "description": "eCPRI front-haul connecting on-board O-DU component to O-RU component on payload bus",
                "type": "iana-if-type:ethernetCsmacd",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 25000000000,
                "physAddress": "aa:bb:cc:22:sat2",
                "statistics": {
                    "inOctets": 91024851201,
                    "inUnicastPkts": 78102914,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 91039851029,
                    "outUnicastPkts": 78110294,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "sat-2/isl-port",
                "description": "High-speed laser cross-link inter-satellite optical interface (100G Coherent Laser)",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 100000000000,
                "physAddress": "aa:bb:cc:33:sat2",
                "statistics": {
                    "inOctets": 110294821041,
                    "inUnicastPkts": 891029410,
                    "inErrors": 1,
                    "inDiscards": 0,
                    "outOctets": 120491029410,
                    "outUnicastPkts": 98102941,
                    "outErrors": 3,
                    "outDiscards": 0
                }
            }
        ],
        "services": []
    },
    {
        "uuid": "node-SAT3",
        "name": "LEO-SAT-3",
        "type": "SATELLITE",
        "layer": "LEO",
        "location": "LEO Orbit 3",
        "ietfSystem": {
            "hostname": "sat-3",
            "contact": "space-ops@telecom.jp",
            "location": "LEO 1200km",
            "platform": {
                "osName": "SpaceOS",
                "osRelease": "1.0",
                "osVersion": "1",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "UTC",
                "currentDatetime": new Date().toISOString()
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": { "coordAccuracy": 1 }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 38,
                    "longitude": 137,
                    "height": 1200000
                }
            }
        },
        "hardware": [
            {
                "uuid": "sat3-bus",
                "name": "JAC-Bus300-Telemetry-Chassis",
                "class": "chassis",
                "manufacturer": "Japan Aerospace Communications",
                "partNumber": "JAC-BUS-300-X1",
                "serialNumber": "JAC-LEO-1003",
                "status": "active",
                "description": "Standard LEO bus chassis providing power distribution, solar propulsion control, orbit status, thermal monitoring, and attitude control.",
                "alias": "SAT3 Telemetry Bus",
                "hardwareRev": "v3.2",
                "mfgDate": "2025-03-30T00:00:00Z"
            },
            {
                "uuid": "sat3-odu",
                "name": "O-DU Payload Processor Unit",
                "class": "module",
                "parentUuid": "sat3-bus",
                "manufacturer": "NEC Space Solutions",
                "partNumber": "ORAN-SAT-DU-Versal-S3",
                "serialNumber": "NEC-DU-LEO-SAT3-11",
                "status": "active",
                "description": "Regenerative space-grade Distributed Unit card with AMD/Xilinx Versal adaptive SoC. Processes MAC, RLC, and High-PHY 5G NTN layers under extreme radiation conditions.",
                "alias": "O-RAN DU Payload Baseband Card",
                "hardwareRev": "Rev C",
                "mfgDate": "2025-05-24T00:00:00Z",
                "softwareRev": [
                    { "name": "Open-DU-SpaceKernel", "revision": "v4.1.2" }
                ]
            },
            {
                "uuid": "sat3-oru",
                "name": "O-RU Digital Front End (DFE) payload",
                "class": "module",
                "parentUuid": "sat3-bus",
                "manufacturer": "Fujitsu Space Electronics",
                "partNumber": "ORAN-SAT-RU-DFE-1200",
                "serialNumber": "FUJ-RU-LEO-SAT3-46",
                "status": "active",
                "description": "Space-grade Radio Unit frontend supporting Open Front-haul Option-7.2x, dynamic digital up/downconversion, and packet synchronization.",
                "alias": "O-RAN RU DFE Front-End Card",
                "hardwareRev": "Rev B",
                "mfgDate": "2025-05-28T00:00:00Z"
            },
            {
                "uuid": "sat3-aesa",
                "name": "Ku/Ka Band Active Phased Array (AESA)",
                "class": "module",
                "parentUuid": "sat3-bus",
                "manufacturer": "Mitsubishi Heavy Space",
                "partNumber": "MHS-AESA-KU-KA-LEO",
                "serialNumber": "MHS-AESA-SAT3-04",
                "status": "active",
                "description": "Active Electronically Scanned Array implementing high-gain dynamic beamforming for 5G-NR user/feeder links.",
                "alias": "AESA steerable multi-beam payload",
                "hardwareRev": "v1.4",
                "mfgDate": "2025-06-04T00:00:00Z"
            },
            {
                "uuid": "sat3-gnss-clk",
                "name": "Locked GNSS Space Disciplined Clock",
                "class": "module",
                "parentUuid": "sat3-bus",
                "manufacturer": "Epson Space Technology",
                "partNumber": "EST-GNSS-CLK-10V",
                "serialNumber": "EPS-CLK-SAT3-107",
                "status": "active",
                "description": "Radiation-hardened GNSS-locked reference oscillator. Provides ultra-stable sub-nanosecond synchronization, satisfying O-RAN ITU-T G.8275.1 standards to compensate for high Doppler shift.",
                "alias": "IEEE 1588v2 Space Reference Clock",
                "hardwareRev": "v2.1",
                "mfgDate": "2025-04-15T00:00:00Z"
            },
            {
                "uuid": "sat3-laser-isl",
                "name": "Laser Terminal Inter-Satellite Link (ISL)",
                "class": "transceiver",
                "parentUuid": "sat3-bus",
                "manufacturer": "Toshiba Space Lab",
                "partNumber": "TOSH-ISL-OPT-100G",
                "serialNumber": "TOSH-ISL-SAT3-90",
                "status": "active",
                "description": "100 Gbps coherent Laser Communication Terminal (LCT) for intra-orbit satellite-to-satellite backhaul. Controlled by fine-pointing mechanism.",
                "alias": "Satellite Optical ISL Card",
                "hardwareRev": "v4.0",
                "mfgDate": "2025-07-03T00:00:00Z"
            }
        ],
        "ietfInterfaces": [
            {
                "name": "sat-3/f1-u",
                "description": "F1-User plane interface mapping active O-DU backhaul to ground gateway via NTN link",
                "type": "iana-if-type:ethernetCsmacd",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 10000000000,
                "physAddress": "aa:bb:cc:11:sat3",
                "statistics": {
                    "inOctets": 4691048192,
                    "inUnicastPkts": 3291049,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 9510294102,
                    "outUnicastPkts": 6841029,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "sat-3/open-front-haul",
                "description": "eCPRI front-haul connecting on-board O-DU component to O-RU component on payload bus",
                "type": "iana-if-type:ethernetCsmacd",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 25000000000,
                "physAddress": "aa:bb:cc:22:sat3",
                "statistics": {
                    "inOctets": 99482104910,
                    "inUnicastPkts": 85102941,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 99491029410,
                    "outUnicastPkts": 85109410,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "sat-3/isl-port",
                "description": "High-speed laser cross-link inter-satellite optical interface (100G Coherent Laser)",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 100000000000,
                "physAddress": "aa:bb:cc:33:sat3",
                "statistics": {
                    "inOctets": 139102941042,
                    "inUnicastPkts": 102941085,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 149201948510,
                    "outUnicastPkts": 110294819,
                    "outErrors": 2,
                    "outDiscards": 0
                }
            }
        ],
        "services": []
    },
    {
        "uuid": "node-SAT4",
        "name": "LEO-SAT-4",
        "type": "SATELLITE",
        "layer": "LEO",
        "location": "LEO Orbit 4",
        "ietfSystem": {
            "hostname": "sat-4",
            "contact": "space-ops@telecom.jp",
            "location": "LEO 1200km",
            "platform": {
                "osName": "SpaceOS",
                "osRelease": "1.0",
                "osVersion": "1",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "UTC",
                "currentDatetime": new Date().toISOString()
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": { "coordAccuracy": 1 }
            },
            "location": {
                "ellipsoid": {
                    "latitude": 41,
                    "longitude": 140,
                    "height": 1200000
                }
            }
        },
        "hardware": [
            {
                "uuid": "sat4-bus",
                "name": "JAC-Bus300-Telemetry-Chassis",
                "class": "chassis",
                "manufacturer": "Japan Aerospace Communications",
                "partNumber": "JAC-BUS-300-X1",
                "serialNumber": "JAC-LEO-1004",
                "status": "active",
                "description": "Standard LEO bus chassis providing power distribution, solar propulsion control, orbit status, thermal monitoring, and attitude control.",
                "alias": "SAT4 Telemetry Bus",
                "hardwareRev": "v3.2",
                "mfgDate": "2025-04-05T00:00:00Z"
            },
            {
                "uuid": "sat4-odu",
                "name": "O-DU Payload Processor Unit",
                "class": "module",
                "parentUuid": "sat4-bus",
                "manufacturer": "NEC Space Solutions",
                "partNumber": "ORAN-SAT-DU-Versal-S4",
                "serialNumber": "NEC-DU-LEO-SAT4-12",
                "status": "active",
                "description": "Regenerative space-grade Distributed Unit card with AMD/Xilinx Versal adaptive SoC. Processes MAC, RLC, and High-PHY 5G NTN layers under extreme radiation conditions.",
                "alias": "O-RAN DU Payload Baseband Card",
                "hardwareRev": "Rev C",
                "mfgDate": "2025-05-24T00:00:00Z",
                "softwareRev": [
                    { "name": "Open-DU-SpaceKernel", "revision": "v4.1.2" }
                ]
            },
            {
                "uuid": "sat4-oru",
                "name": "O-RU Digital Front End (DFE) payload",
                "class": "module",
                "parentUuid": "sat4-bus",
                "manufacturer": "Fujitsu Space Electronics",
                "partNumber": "ORAN-SAT-RU-DFE-1200",
                "serialNumber": "FUJ-RU-LEO-SAT4-47",
                "status": "active",
                "description": "Space-grade Radio Unit frontend supporting Open Front-haul Option-7.2x, dynamic digital up/downconversion, and packet synchronization.",
                "alias": "O-RAN RU DFE Front-End Card",
                "hardwareRev": "Rev B",
                "mfgDate": "2025-05-28T00:00:00Z"
            },
            {
                "uuid": "sat4-aesa",
                "name": "Ku/Ka Band Active Phased Array (AESA)",
                "class": "module",
                "parentUuid": "sat4-bus",
                "manufacturer": "Mitsubishi Heavy Space",
                "partNumber": "MHS-AESA-KU-KA-LEO",
                "serialNumber": "MHS-AESA-SAT4-05",
                "status": "active",
                "description": "Active Electronically Scanned Array implementing high-gain dynamic beamforming for 5G-NR user/feeder links.",
                "alias": "AESA steerable multi-beam payload",
                "hardwareRev": "v1.4",
                "mfgDate": "2025-06-05T00:00:00Z"
            },
            {
                "uuid": "sat4-gnss-clk",
                "name": "Locked GNSS Space Disciplined Clock",
                "class": "module",
                "parentUuid": "sat4-bus",
                "manufacturer": "Epson Space Technology",
                "partNumber": "EST-GNSS-CLK-10V",
                "serialNumber": "EPS-CLK-SAT4-108",
                "status": "active",
                "description": "Radiation-hardened GNSS-locked reference oscillator. Provides ultra-stable sub-nanosecond synchronization, satisfying O-RAN ITU-T G.8275.1 standards to compensate for high Doppler shift.",
                "alias": "IEEE 1588v2 Space Reference Clock",
                "hardwareRev": "v2.1",
                "mfgDate": "2025-04-18T00:00:00Z"
            },
            {
                "uuid": "sat4-laser-isl",
                "name": "Laser Terminal Inter-Satellite Link (ISL)",
                "class": "transceiver",
                "parentUuid": "sat4-bus",
                "manufacturer": "Toshiba Space Lab",
                "partNumber": "TOSH-ISL-OPT-100G",
                "serialNumber": "TOSH-ISL-SAT4-91",
                "status": "active",
                "description": "100 Gbps coherent Laser Communication Terminal (LCT) for intra-orbit satellite-to-satellite backhaul. Controlled by fine-pointing mechanism.",
                "alias": "Satellite Optical ISL Card",
                "hardwareRev": "v4.0",
                "mfgDate": "2025-07-04T00:00:00Z"
            }
        ],
        "ietfInterfaces": [
            {
                "name": "sat-4/f1-u",
                "description": "F1-User plane interface mapping active O-DU backhaul to ground gateway via NTN link",
                "type": "iana-if-type:ethernetCsmacd",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 10000000000,
                "physAddress": "aa:bb:cc:11:sat4",
                "statistics": {
                    "inOctets": 4120910248,
                    "inUnicastPkts": 2851029,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 8510294109,
                    "outUnicastPkts": 5910241,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "sat-4/open-front-haul",
                "description": "eCPRI front-haul connecting on-board O-DU component to O-RU component on payload bus",
                "type": "iana-if-type:ethernetCsmacd",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 25000000000,
                "physAddress": "aa:bb:cc:22:sat4",
                "statistics": {
                    "inOctets": 88102941029,
                    "inUnicastPkts": 72102941,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 88110294810,
                    "outUnicastPkts": 72105102,
                    "outErrors": 0,
                    "outDiscards": 0
                }
            },
            {
                "name": "sat-4/isl-port",
                "description": "High-speed laser cross-link inter-satellite optical interface (100G Coherent Laser)",
                "type": "iana-if-type:opticalChannel",
                "enabled": true,
                "adminStatus": "up",
                "operStatus": "up",
                "speed": 100000000000,
                "physAddress": "aa:bb:cc:33:sat4",
                "statistics": {
                    "inOctets": 102941082104,
                    "inUnicastPkts": 851029410,
                    "inErrors": 0,
                    "inDiscards": 0,
                    "outOctets": 110294108294,
                    "outUnicastPkts": 91024821,
                    "outErrors": 1,
                    "outDiscards": 0
                }
            }
        ],
        "services": []
    }
] as NetworkElement[],
        links: [
    {
        "uuid": "link-node-TK1-CU-node-TK1",
        "sourceNodeUuid": "node-TK1",
        "targetNodeUuid": "CU-node-TK1",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-TK1-TerraBeam-node-TK1",
        "sourceNodeUuid": "CU-node-TK1",
        "targetNodeUuid": "TerraBeam-node-TK1",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-TH_OTE-CU-node-TH_OTE",
        "sourceNodeUuid": "node-TH_OTE",
        "targetNodeUuid": "CU-node-TH_OTE",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-TH_OTE-TerraBeam-node-TH_OTE",
        "sourceNodeUuid": "CU-node-TH_OTE",
        "targetNodeUuid": "TerraBeam-node-TH_OTE",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-TY1-CU-node-TY1",
        "sourceNodeUuid": "node-TY1",
        "targetNodeUuid": "CU-node-TY1",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-TY1-TerraBeam-node-TY1",
        "sourceNodeUuid": "CU-node-TY1",
        "targetNodeUuid": "TerraBeam-node-TY1",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-CC1-CU-node-CC1",
        "sourceNodeUuid": "node-CC1",
        "targetNodeUuid": "CU-node-CC1",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-CC1-TerraBeam-node-CC1",
        "sourceNodeUuid": "CU-node-CC1",
        "targetNodeUuid": "TerraBeam-node-CC1",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-FUJI_SUMMIT-CU-node-FUJI_SUMMIT",
        "sourceNodeUuid": "node-FUJI_SUMMIT",
        "targetNodeUuid": "CU-node-FUJI_SUMMIT",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-FUJI_SUMMIT-TerraBeam-node-FUJI_SUMMIT",
        "sourceNodeUuid": "CU-node-FUJI_SUMMIT",
        "targetNodeUuid": "TerraBeam-node-FUJI_SUMMIT",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-TYO2-CU-node-TYO2",
        "sourceNodeUuid": "node-TYO2",
        "targetNodeUuid": "CU-node-TYO2",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-TYO2-TerraBeam-node-TYO2",
        "sourceNodeUuid": "CU-node-TYO2",
        "targetNodeUuid": "TerraBeam-node-TYO2",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-M_CLS-CU-node-M_CLS",
        "sourceNodeUuid": "node-M_CLS",
        "targetNodeUuid": "CU-node-M_CLS",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-M_CLS-TerraBeam-node-M_CLS",
        "sourceNodeUuid": "CU-node-M_CLS",
        "targetNodeUuid": "TerraBeam-node-M_CLS",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-OS1-CU-node-OS1",
        "sourceNodeUuid": "node-OS1",
        "targetNodeUuid": "CU-node-OS1",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-OS1-TerraBeam-node-OS1",
        "sourceNodeUuid": "CU-node-OS1",
        "targetNodeUuid": "TerraBeam-node-OS1",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-OS3-CU-node-OS3",
        "sourceNodeUuid": "node-OS3",
        "targetNodeUuid": "CU-node-OS3",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-OS3-TerraBeam-node-OS3",
        "sourceNodeUuid": "CU-node-OS3",
        "targetNodeUuid": "TerraBeam-node-OS3",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-DC12-CU-node-DC12",
        "sourceNodeUuid": "node-DC12",
        "targetNodeUuid": "CU-node-DC12",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-DC12-TerraBeam-node-DC12",
        "sourceNodeUuid": "CU-node-DC12",
        "targetNodeUuid": "TerraBeam-node-DC12",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-EQ_OS1-CU-node-EQ_OS1",
        "sourceNodeUuid": "node-EQ_OS1",
        "targetNodeUuid": "CU-node-EQ_OS1",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-EQ_OS1-TerraBeam-node-EQ_OS1",
        "sourceNodeUuid": "CU-node-EQ_OS1",
        "targetNodeUuid": "TerraBeam-node-EQ_OS1",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-KOZU-CU-node-KOZU",
        "sourceNodeUuid": "node-KOZU",
        "targetNodeUuid": "CU-node-KOZU",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-KOZU-TerraBeam-node-KOZU",
        "sourceNodeUuid": "CU-node-KOZU",
        "targetNodeUuid": "TerraBeam-node-KOZU",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-SP_OD-CU-node-SP_OD",
        "sourceNodeUuid": "node-SP_OD",
        "targetNodeUuid": "CU-node-SP_OD",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-SP_OD-TerraBeam-node-SP_OD",
        "sourceNodeUuid": "CU-node-SP_OD",
        "targetNodeUuid": "TerraBeam-node-SP_OD",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-SD_CH-CU-node-SD_CH",
        "sourceNodeUuid": "node-SD_CH",
        "targetNodeUuid": "CU-node-SD_CH",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-SD_CH-TerraBeam-node-SD_CH",
        "sourceNodeUuid": "CU-node-SD_CH",
        "targetNodeUuid": "TerraBeam-node-SD_CH",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-NG_SM-CU-node-NG_SM",
        "sourceNodeUuid": "node-NG_SM",
        "targetNodeUuid": "CU-node-NG_SM",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-NG_SM-TerraBeam-node-NG_SM",
        "sourceNodeUuid": "CU-node-NG_SM",
        "targetNodeUuid": "TerraBeam-node-NG_SM",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-FK_TJ-CU-node-FK_TJ",
        "sourceNodeUuid": "node-FK_TJ",
        "targetNodeUuid": "CU-node-FK_TJ",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-FK_TJ-TerraBeam-node-FK_TJ",
        "sourceNodeUuid": "CU-node-FK_TJ",
        "targetNodeUuid": "TerraBeam-node-FK_TJ",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-node-OK_NH-CU-node-OK_NH",
        "sourceNodeUuid": "node-OK_NH",
        "targetNodeUuid": "CU-node-OK_NH",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-CU-node-OK_NH-TerraBeam-node-OK_NH",
        "sourceNodeUuid": "CU-node-OK_NH",
        "targetNodeUuid": "TerraBeam-node-OK_NH",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-TK1-TH_OTE",
        "sourceNodeUuid": "node-TK1",
        "targetNodeUuid": "node-TH_OTE",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-TH_OTE-CC1",
        "sourceNodeUuid": "node-TH_OTE",
        "targetNodeUuid": "node-CC1",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 55
    },
    {
        "uuid": "link-CC1-TY1",
        "sourceNodeUuid": "node-CC1",
        "targetNodeUuid": "node-TY1",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 65
    },
    {
        "uuid": "link-TY1-FUJI_SUMMIT",
        "sourceNodeUuid": "node-TY1",
        "targetNodeUuid": "node-FUJI_SUMMIT",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 50
    },
    {
        "uuid": "link-FUJI_SUMMIT-TYO2",
        "sourceNodeUuid": "node-FUJI_SUMMIT",
        "targetNodeUuid": "node-TYO2",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 40
    },
    {
        "uuid": "link-TYO2-TK1",
        "sourceNodeUuid": "node-TYO2",
        "targetNodeUuid": "node-TK1",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 60
    },
    {
        "uuid": "link-OS1-OS3",
        "sourceNodeUuid": "node-OS1",
        "targetNodeUuid": "node-OS3",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-OS3-DC12",
        "sourceNodeUuid": "node-OS3",
        "targetNodeUuid": "node-DC12",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 50
    },
    {
        "uuid": "link-DC12-EQ_OS1",
        "sourceNodeUuid": "node-DC12",
        "targetNodeUuid": "node-EQ_OS1",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 60
    },
    {
        "uuid": "link-EQ_OS1-KOZU",
        "sourceNodeUuid": "node-EQ_OS1",
        "targetNodeUuid": "node-KOZU",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 55
    },
    {
        "uuid": "link-KOZU-OS1",
        "sourceNodeUuid": "node-KOZU",
        "targetNodeUuid": "node-OS1",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 40
    },
    {
        "uuid": "link-TK1-OS1",
        "sourceNodeUuid": "node-TK1",
        "targetNodeUuid": "node-OS1",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 85
    },
    {
        "uuid": "link-TY1-EQ_OS1",
        "sourceNodeUuid": "node-TY1",
        "targetNodeUuid": "node-EQ_OS1",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 75
    },
    {
        "uuid": "link-M_CLS-TK1",
        "sourceNodeUuid": "node-M_CLS",
        "targetNodeUuid": "node-TK1",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 30
    },
    {
        "uuid": "link-SP_OD-TK1",
        "sourceNodeUuid": "node-SP_OD",
        "targetNodeUuid": "node-TK1",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 40
    },
    {
        "uuid": "link-SD_CH-TK1",
        "sourceNodeUuid": "node-SD_CH",
        "targetNodeUuid": "node-TK1",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 35
    },
    {
        "uuid": "link-NG_SM-DC12",
        "sourceNodeUuid": "node-NG_SM",
        "targetNodeUuid": "node-DC12",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 45
    },
    {
        "uuid": "link-FK_TJ-OS1",
        "sourceNodeUuid": "node-FK_TJ",
        "targetNodeUuid": "node-OS1",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 50
    },
    {
        "uuid": "link-OK_NH-FK_TJ",
        "sourceNodeUuid": "node-OK_NH",
        "targetNodeUuid": "node-FK_TJ",
        "sourcePortUuid": "opt-1/1",
        "targetPortUuid": "opt-1/1",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 30
    },
    {
        "uuid": "link-NG_SM-TK1",
        "sourceNodeUuid": "node-NG_SM",
        "targetNodeUuid": "node-TK1",
        "sourcePortUuid": "opt-1/2",
        "targetPortUuid": "opt-1/2",
        "layer": "L0 (Optical)",
        "capacity": "800 Gbps",
        "usage": 45
    }
,
    {
        "uuid": "link-SAT1-SAT2",
        "sourceNodeUuid": "node-SAT1",
        "targetNodeUuid": "node-SAT2",
        "sourcePortUuid": "sat-port",
        "targetPortUuid": "sat-port",
        "layer": "ISL (Inter-Satellite Link)",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "100 Gbps",
        "usage": 10
    },
    {
        "uuid": "link-SAT2-SAT3",
        "sourceNodeUuid": "node-SAT2",
        "targetNodeUuid": "node-SAT3",
        "sourcePortUuid": "sat-port",
        "targetPortUuid": "sat-port",
        "layer": "ISL (Inter-Satellite Link)",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "100 Gbps",
        "usage": 10
    },
    {
        "uuid": "link-SAT3-SAT4",
        "sourceNodeUuid": "node-SAT3",
        "targetNodeUuid": "node-SAT4",
        "sourcePortUuid": "sat-port",
        "targetPortUuid": "sat-port",
        "layer": "ISL (Inter-Satellite Link)",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "100 Gbps",
        "usage": 10
    },
    {
        "uuid": "link-node-TK1-node-SAT1",
        "sourceNodeUuid": "TerraBeam-node-TK1",
        "targetNodeUuid": "node-SAT1",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-TH_OTE-node-SAT2",
        "sourceNodeUuid": "TerraBeam-node-TH_OTE",
        "targetNodeUuid": "node-SAT2",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-TY1-node-SAT3",
        "sourceNodeUuid": "TerraBeam-node-TY1",
        "targetNodeUuid": "node-SAT3",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-CC1-node-SAT4",
        "sourceNodeUuid": "TerraBeam-node-CC1",
        "targetNodeUuid": "node-SAT4",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-FUJI_SUMMIT-node-SAT1",
        "sourceNodeUuid": "TerraBeam-node-FUJI_SUMMIT",
        "targetNodeUuid": "node-SAT1",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-TYO2-node-SAT2",
        "sourceNodeUuid": "TerraBeam-node-TYO2",
        "targetNodeUuid": "node-SAT2",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-M_CLS-node-SAT3",
        "sourceNodeUuid": "TerraBeam-node-M_CLS",
        "targetNodeUuid": "node-SAT3",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-OS1-node-SAT4",
        "sourceNodeUuid": "TerraBeam-node-OS1",
        "targetNodeUuid": "node-SAT4",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-OS3-node-SAT1",
        "sourceNodeUuid": "TerraBeam-node-OS3",
        "targetNodeUuid": "node-SAT1",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-DC12-node-SAT2",
        "sourceNodeUuid": "TerraBeam-node-DC12",
        "targetNodeUuid": "node-SAT2",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-EQ_OS1-node-SAT3",
        "sourceNodeUuid": "TerraBeam-node-EQ_OS1",
        "targetNodeUuid": "node-SAT3",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-KOZU-node-SAT4",
        "sourceNodeUuid": "TerraBeam-node-KOZU",
        "targetNodeUuid": "node-SAT4",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-SP_OD-node-SAT1",
        "sourceNodeUuid": "TerraBeam-node-SP_OD",
        "targetNodeUuid": "node-SAT1",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-SD_CH-node-SAT2",
        "sourceNodeUuid": "TerraBeam-node-SD_CH",
        "targetNodeUuid": "node-SAT2",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-NG_SM-node-SAT3",
        "sourceNodeUuid": "TerraBeam-node-NG_SM",
        "targetNodeUuid": "node-SAT3",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-FK_TJ-node-SAT4",
        "sourceNodeUuid": "TerraBeam-node-FK_TJ",
        "targetNodeUuid": "node-SAT4",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    },
    {
        "uuid": "link-node-OK_NH-node-SAT1",
        "sourceNodeUuid": "TerraBeam-node-OK_NH",
        "targetNodeUuid": "node-SAT1",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "inventoryMappingAttributes": {
            "linkType": "free-space-optics"
        },
        "capacity": "10 Gbps",
        "usage": 5
    }
] as NetworkLink[]
    };
}
