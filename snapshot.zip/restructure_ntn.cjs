const fs = require('fs');
const path = require('path');

const topoPath = path.join(__dirname, 'src', 'lib', 'mock-japanese-topology.ts');
let content = fs.readFileSync(topoPath, 'utf8');

// 1. Remove previously injected O-CU modules from hardware arrays
const cuHardwareRegex = /\s*\{\s*"uuid": "CU-node-[^"]+",\s*"name": "O-RAN Centralized Unit \(O-CU\)"[\s\S]*?"description": "5G NTN Centralized Unit[^"]*"\s*\},?/gi;
content = content.replace(cuHardwareRegex, '');
const cuHardwareRegex2 = /\s*\{\s*"uuid": "cu-node-[^"]+",\s*"name": "O-RAN Centralized Unit \(O-CU\)"[\s\S]*?"description": "5G NTN Centralized Unit[^"]*"\s*\},?/gi;
content = content.replace(cuHardwareRegex2, '');

const groundNodes = [
    'node-TK1', 'node-TH_OTE', 'node-TY1', 'node-CC1', 
    'node-FUJI_SUMMIT', 'node-TYO2', 'node-M_CLS', 'node-OS1', 
    'node-OS3', 'node-DC12', 'node-EQ_OS1', 'node-KOZU', 
    'node-SP_OD', 'node-SD_CH', 'node-NG_SM', 'node-FK_TJ', 'node-OK_NH'
];

const manufacturers = [
    'NEC Corporation',
    'Fujitsu',
    'Rakuten Symphony'
];

let newNodesStr = '';
let newLinksStr = '';

let counter = 0;

groundNodes.forEach(nodeUuid => {
    const manufacturer = manufacturers[counter % manufacturers.length];
    counter++;

    const cuUuid = 'CU-' + nodeUuid;
    const tbUuid = 'TerraBeam-' + nodeUuid;

    // Determine location properties
    let locationNotes = '';
    let rackId = 'Rack-' + (Math.floor(Math.random() * 50) + 1);
    let siteName = 'NTN Ground Station Site';
    let building = 'Telco Hut';
    let locString = 'NTN Ground Station';

    if (nodeUuid === 'node-FUJI_SUMMIT') {
        siteName = 'Mt. Fuji Summit Observatory';
        building = 'Telecom Hut Alpha';
        rackId = 'Rack-1';
        locationNotes = 'Telco hut co-locates 3 additional empty/third-party racks.';
        locString = 'Mount Fuji';
    }

    const facilityLocation = `{
            "siteName": "${siteName}",
            "buildingOrHut": "${building}",
            "rackIdentifier": "${rackId}",
            "rackPosition": 22,
            "notes": "${locationNotes}"
        }`;

    const cuNode = `
    {
        "uuid": "${cuUuid}",
        "name": "O-CU-Server",
        "type": "SERVER",
        "layer": "L2_ETHERNET",
        "location": "${locString}",
        "ietfSystem": {
            "hostname": "${cuUuid.toLowerCase()}",
            "contact": "ntn-ops@telecom.jp",
            "platform": { "osName": "Linux", "osRelease": "5.15", "osVersion": "Ubuntu", "machine": "x86_64" },
            "clock": { "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": ${facilityLocation},
        "hardware": [
            {
                "uuid": "srv-${cuUuid}",
                "name": "O-CU Server Chassis",
                "class": "chassis",
                "manufacturer": "${manufacturer}",
                "partNumber": "NTN-CU-SRV",
                "serialNumber": "SRV-${Math.floor(Math.random() * 10000)}",
                "status": "active"
            }
        ],
        "services": []
    },`;

    const tbNode = `
    {
        "uuid": "${tbUuid}",
        "name": "Aalyria TerraBeam Transponder",
        "type": "TRANSPONDER",
        "layer": "L0_OPTICAL",
        "location": "${locString}",
        "ietfSystem": {
            "hostname": "${tbUuid.toLowerCase()}",
            "contact": "space-ops@telecom.jp",
            "platform": { "osName": "TerraOS", "osRelease": "2.0", "osVersion": "2", "machine": "arm64" },
            "clock": { "timezoneName": "Asia/Tokyo", "currentDatetime": "2026-05-02T02:35:36.539Z" }
        },
        "facilityLocation": ${facilityLocation},
        "hardware": [
            {
                "uuid": "tb-ch-${tbUuid}",
                "name": "TerraBeam FSO Terminal",
                "class": "chassis",
                "manufacturer": "Aalyria",
                "partNumber": "TERRABEAM-FSO",
                "serialNumber": "AAL-${Math.floor(Math.random() * 10000)}",
                "status": "active"
            }
        ],
        "services": []
    },`;

    newNodesStr += cuNode + tbNode;

    const linkSwitchToCu = `
    {
        "uuid": "link-${nodeUuid}-${cuUuid}",
        "sourceNodeUuid": "${nodeUuid}",
        "targetNodeUuid": "${cuUuid}",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },`;

    const linkCuToTb = `
    {
        "uuid": "link-${cuUuid}-${tbUuid}",
        "sourceNodeUuid": "${cuUuid}",
        "targetNodeUuid": "${tbUuid}",
        "sourcePortUuid": "eth-out",
        "targetPortUuid": "eth-in",
        "layer": "L2_ETHERNET",
        "capacity": "100 Gbps",
        "usage": 45
    },`;

    newLinksStr += linkSwitchToCu + linkCuToTb;

    // Change existing NTN backhaul link to originate from TerraBeam instead of Optical Switch
    const linkSourceRegex = new RegExp(`("uuid":\\s*"link-${nodeUuid}-node-SAT\\d+",\\s*"sourceNodeUuid":\\s*)"${nodeUuid}"`, "g");
    content = content.replace(linkSourceRegex, `$1"${tbUuid}"`);
    
    // Some links might be named link-node-SAT... wait. The uuid is usually link-[source]-[dest].
    // If it's link-node-OS3-node-SAT1, it matches `link-${nodeUuid}-node-SAT\\d+`.
});

// Inject new nodes into `nodes: [`
const nodesStartIndex = content.indexOf('nodes: [');
if (nodesStartIndex !== -1) {
    const insertNodesPos = content.indexOf('[', nodesStartIndex) + 1;
    content = content.slice(0, insertNodesPos) + newNodesStr + content.slice(insertNodesPos);
} else {
    console.log("Could not find nodes array.");
}

// Inject new links into `links: [`
const linksStartIndex = content.indexOf('links: [');
if (linksStartIndex !== -1) {
    const insertLinksPos = content.indexOf('[', linksStartIndex) + 1;
    content = content.slice(0, insertLinksPos) + newLinksStr + content.slice(insertLinksPos);
} else {
    console.log("Could not find links array.");
}

fs.writeFileSync(topoPath, content, 'utf8');
console.log("Successfully restructured ground segment architecture.");
