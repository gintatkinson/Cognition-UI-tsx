import fs from 'fs';

let content = fs.readFileSync('src/lib/mock-japanese-topology.ts', 'utf8');

const nodesEndMatch = content.match(/] as NetworkElement\[\],\s*links: \[\s*/);
if (!nodesEndMatch) throw new Error("nodes end not found");

const linksEndMatch = content.match(/] as NetworkLink\[\]\s*};\s*}\s*$/);
if (!linksEndMatch) {
    // If not matching, just try to find the end of the file.
    console.log("fallback");
}

// Define sat nodes
const sats = [
  { lat: 28.0, lon: 129.0, name: "LEO-SAT-1", uuid: "node-SAT1" },
  { lat: 33.0, lon: 133.0, name: "LEO-SAT-2", uuid: "node-SAT2" },
  { lat: 38.0, lon: 137.0, name: "LEO-SAT-3", uuid: "node-SAT3" },
  { lat: 41.0, lon: 140.0, name: "LEO-SAT-4", uuid: "node-SAT4" },
];

let addedNodes = sats.map((sat, i) => `{
        "uuid": "${sat.uuid}",
        "name": "${sat.name}",
        "type": "SATELLITE",
        "layer": "LEO",
        "location": "LEO Orbit ${i+1}",
        "ietfSystem": {
            "hostname": "sat-${i+1}",
            "contact": "space-ops@telecom.jp",
            "location": "LEO 1200km",
            "platform": {
                "osName": "SpaceOS",
                "osRelease": "1.0",
                "osVersion": "1",
                "machine": "x86_64"
            },
            "clock": {
                "timezoneName": "UTC",
                "currentDatetime": new Date().toISOString()
            }
        },
        "ietfGeoLocation": {
            "referenceFrame": {
                "astronomicalBody": "earth",
                "geodeticSystem": { "coordAccuracy": 1 }
            },
            "location": {
                "ellipsoid": {
                    "latitude": ${sat.lat},
                    "longitude": ${sat.lon},
                    "height": 1200000
                }
            }
        },
        "hardware": [],
        "ietfInterfaces": [],
        "services": []
    }`).join(',\n    ');

const nodesRegex = /"uuid":\s*"node-([A-Z0-9_]+)"/g;
let match;
let terrestrialNodes = [];
while ((match = nodesRegex.exec(content)) !== null) {
  if (!match[1].startsWith("SAT")) {
    terrestrialNodes.push("node-" + match[1]);
  }
}

let links = [];
for (let i = 0; i < sats.length - 1; i++) {
  links.push(`{
        "uuid": "link-SAT${i+1}-SAT${i+2}",
        "sourceNodeUuid": "node-SAT${i+1}",
        "targetNodeUuid": "node-SAT${i+2}",
        "sourcePortUuid": "sat-port",
        "targetPortUuid": "sat-port",
        "layer": "ISL (Inter-Satellite Link)",
        "capacity": "100 Gbps",
        "usage": 10
    }`);
}

terrestrialNodes.forEach((nodeUuid, idx) => {
  const satId = "node-SAT" + ((idx % 4) + 1);
  links.push(`{
        "uuid": "link-${nodeUuid}-${satId}",
        "sourceNodeUuid": "${nodeUuid}",
        "targetNodeUuid": "${satId}",
        "sourcePortUuid": "up-down-link",
        "targetPortUuid": "sat-downlink",
        "layer": "NTN-Backhaul",
        "capacity": "10 Gbps",
        "usage": 5
    }`);
});

let addedLinks = links.join(',\n    ');

// Reconstruct
let newContent = content.slice(0, nodesEndMatch.index) + ',\n    ' + addedNodes + '\n' + content.slice(nodesEndMatch.index);

// Insert links before '] as NetworkLink[]'
const lastBrack = newContent.lastIndexOf('] as NetworkLink[]');
newContent = newContent.slice(0, lastBrack) + ',\n    ' + addedLinks + '\n' + newContent.slice(lastBrack);

fs.writeFileSync('src/lib/mock-japanese-topology.ts', newContent, 'utf8');
console.log("Topology updated.");
