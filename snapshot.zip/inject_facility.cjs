const fs = require('fs');
const path = require('path');

const topoPath = path.join(__dirname, 'src', 'lib', 'mock-japanese-topology.ts');
let content = fs.readFileSync(topoPath, 'utf8');

const groundNodes = [
    'node-TK1', 'node-TH_OTE', 'node-TY1', 'node-CC1', 
    'node-FUJI_SUMMIT', 'node-TYO2', 'node-M_CLS', 'node-OS1', 
    'node-OS3', 'node-DC12', 'node-EQ_OS1', 'node-KOZU', 
    'node-SP_OD', 'node-SD_CH', 'node-NG_SM', 'node-FK_TJ', 'node-OK_NH'
];

groundNodes.forEach(nodeUuid => {
    let siteName = 'NTN Ground Station Site';
    let building = 'Telco Hut';
    let rackId = 'Rack-' + (Math.floor(Math.random() * 50) + 1);
    let locationNotes = '';

    if (nodeUuid === 'node-FUJI_SUMMIT') {
        siteName = 'Mt. Fuji Summit Observatory';
        building = 'Telecom Hut Alpha';
        rackId = 'Rack-1';
        locationNotes = 'Telco hut co-locates 3 additional empty/third-party racks.';
    }

    const facilityLocation = `\n        "facilityLocation": {
            "siteName": "${siteName}",
            "buildingOrHut": "${building}",
            "rackIdentifier": "${rackId}",
            "rackPosition": 22,
            "notes": "${locationNotes}"
        },`;

    // Only inject if it doesn't already have facilityLocation right after the type or layer
    const searchString = `"uuid": "${nodeUuid}",`;
    const searchIndex = content.indexOf(searchString);
    if (searchIndex !== -1) {
        // find the end of this node's 'name' or 'type' to inject
        const nameIndex = content.indexOf('"name":', searchIndex);
        if (nameIndex !== -1) {
            const endOfLine = content.indexOf(',', nameIndex);
            
            // Check if it already has facilityLocation right after
            const nextFewChars = content.substring(endOfLine, endOfLine + 200);
            if (!nextFewChars.includes('"facilityLocation"')) {
                content = content.slice(0, endOfLine + 1) + facilityLocation + content.slice(endOfLine + 1);
            }
        }
    }
});

fs.writeFileSync(topoPath, content, 'utf8');
console.log("Successfully injected facilityLocation to optical nodes.");
